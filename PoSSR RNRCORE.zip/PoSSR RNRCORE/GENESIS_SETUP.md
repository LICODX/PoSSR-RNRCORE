# Genesis Setup Guide

Panduan membuat Genesis Wallet dan Genesis Block untuk mainnet.

---

## 🔑 Langkah 1: Generate Genesis Wallet

### Build Tool
```powershell
cd C:\Users\Administrator\Documents\PoSSR RNRCORE
go build -o genesis-wallet.exe .\cmd\genesis-wallet
```

### Generate Wallet
```powershell
.\genesis-wallet.exe
```

**Output**:
```
🔑 Genesis Wallet Generator
==================================================

✅ Genesis Wallet Created!

📄 WALLET INFORMATION:
Address: a1b2c3d4e5f6...
Private Key: 1234567890abcdef...

💾 Wallet saved to: genesis_wallet.json

⚠️  IMPORTANT:
   1. BACKUP private key immediately!
   2. This wallet will receive initial supply (5B RNR)
   3. Keep genesis_wallet.json in SAFE location
   4. Use this address in genesis.go for mainnet
```

### BACKUP Private Key!
File `genesis_wallet.json` berisi:
```json
{
  "address": "a1b2c3d4e5f6...",
  "private_key": "1234567890abcdef...",
  "public_key": "..."
}
```

**⚠️ SIMPAN FILE INI DI TEMPAT AMAN!**

---

## 📦 Langkah 2: Setup Genesis Block

### File: `internal/blockchain/genesis.go`

Genesis Block sudah otomatis dibuat saat pertama kali node jalan. Block ini berisi:
- Height: 0
- Timestamp: Saat node pertama kali start
- VRF Seed: Random (secure)
- Empty transactions

### Untuk Mainnet: Tambahkan Initial Supply

Edit `genesis.go` untuk menambahkan balance ke Genesis Wallet:

```go
package blockchain

import (
	"crypto/rand"
	"time"

	"github.com/username/rnr-core/pkg/types"
)

var GenesisBlock = types.Block{
	Header: types.BlockHeader{
		Version:   1,
		Height:    0,
		Timestamp: 1704067200, // Fixed: 1 Jan 2024 00:00:00 UTC
		VRFSeed:   [32]byte{1, 2, 3, 4, 5}, // Will be replaced
	},
}

// GenesisWalletAddress - Address yang menerima initial supply
// GANTI DENGAN ADDRESS DARI genesis_wallet.json
const GenesisWalletAddress = "PASTE_YOUR_ADDRESS_HERE"

// CreateGenesisBlock returns the genesis block
func CreateGenesisBlock() types.Block {
	// Generate random VRF seed using crypto/rand
	var seed [32]byte
	rand.Read(seed[:])
	
	block := GenesisBlock
	block.Header.Timestamp = time.Now().Unix()
	block.Header.VRFSeed = seed
	
	// TODO: Add initial balance allocation
	// This would require creating a genesis transaction
	// to allocate 5B RNR to GenesisWalletAddress
	
	return block
}
```

---

## 🚀 Langkah 3: Launch Mainnet

### 1. Generate Genesis Wallet
```powershell
.\genesis-wallet.exe
```

### 2. Backup Wallet File
```powershell
copy genesis_wallet.json D:\BACKUP\genesis_wallet_BACKUP.json
```

### 3. Update genesis.go
- Copy address dari `genesis_wallet.json`
- Paste ke `GenesisWalletAddress` di `genesis.go`

### 4. Rebuild Node
```powershell
go build -o rnr-node.exe .\cmd\rnr-node
```

### 5. Start Mainnet Node
```powershell
.\rnr-node.exe --port 3000 --datadir .\mainnet-data
```

Genesis Block akan dibuat otomatis saat pertama kali node start!

---

## 📊 Verifikasi Genesis Block

### Check via RPC:
```powershell
curl -X POST http://localhost:9545 -H "Content-Type: application/json" -d '{
  "jsonrpc": "2.0",
  "method": "eth_getBlockByNumber",
  "params": ["0x0", true],
  "id": 1
}'
```

### Check via Dashboard:
```
http://localhost:8080
```

Lihat block #0 di recent blocks list.

---

## 🔐 Keamanan Genesis Wallet

### DO ✅
- Backup private key ke 3+ lokasi berbeda
- Simpan di password manager (LastPass, 1Password)
- Print dan simpan di safe/brankas
- Encrypt file dengan GPG

### DON'T ❌
- Jangan share private key ke siapapun
- Jangan upload ke GitHub/cloud
- Jangan simpan di plain text di email
- Jangan screenshot dan share

---

## ❓ FAQ

**Q: Apa itu Genesis Wallet?**
A: Wallet pertama yang menerima initial supply (5 Billion RNR) saat blockchain launch.

**Q: Apa itu Genesis Block?**
A: Block pertama (height 0) dalam blockchain. Semua block lain terhubung ke genesis block.

**Q: Apakah bisa ganti Genesis Block setelah mainnet launch?**
A: TIDAK! Genesis block permanent. Harus benar dari awal.

**Q: Bagaimana cara distribusi dari Genesis Wallet?**
A: Gunakan wallet untuk transfer ke address lain (team, investors, community airdrop, dll)

**Q: Apakah Genesis Wallet harus online terus?**
A: Tidak. Wallet hanya perlu ketika mau kirim transaksi.

---

## 🎯 Checklist Mainnet Launch

- [ ] Generate Genesis Wallet
- [ ] Backup private key (3+ lokasi)
- [ ] Update genesis.go dengan address
- [ ] Test di local node
- [ ] Build final binary
- [ ] Launch seed nodes (min 3)
- [ ] Announce mainnet launch
- [ ] Monitor first 100 blocks
- [ ] Distribute initial tokens dari Genesis Wallet

---

## 🆘 Need Help?

Jika ada masalah saat generate Genesis:
1. Pastikan Go terinstall
2. Run `go mod tidy`
3. Check error message
4. Hubungi developer di Discord/Telegram
