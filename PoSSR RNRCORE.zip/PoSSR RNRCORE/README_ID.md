# rnr-core

**Blockchain Proof of Sequential Sorting Race (PoSSR)**

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Versi Go](https://img.shields.io/badge/go-1.21+-blue.svg)](https://go.dev)
[![Mainnet Ready](https://img.shields.io/badge/mainnet-98%25-green.svg)](PROJECT_AUDIT.md)

> Blockchain Layer-1 berkinerja tinggi menggunakan algoritma sorting. Mampu mencapai 35,000+ TPS dengan blok 1 GB yang dikumpulkan dari 10 shard paralel.

---

## 🚀 Mulai Cepat

### Unduh & Jalankan

```powershell
# Windows
.\rnr-node.exe

# Lihat dashboard
http://localhost:8080
```

### Atau Build dari Source

```bash
git clone https://github.com/username/rnr-core.git
cd rnr-core
go mod tidy
go build -o rnr-node ./cmd/rnr-node
./rnr-node
```

---

## ✨ Fitur Utama

### 🔥 Performa Tinggi
- **35,000+ TPS**: Pemrosesan shard paralel
- **Waktu Blok 60 Detik**: Finalitas cepat
- **Blok 1 GB**: Throughput masif

### 🔒 Keamanan
- **Enkripsi TLS**: Komunikasi P2P aman (Noise + TLS13)
- **Tanda Tangan ED25519**: Keamanan kriptografi standar industri
- **Skor Keamanan 95%**: 23 kerentanan telah diperbaiki

### 🌐 Jaringan Modern
- **GossipSub P2P**: Jaringan mesh otomatis (seperti IPFS/Ethereum 2.0)
- **Penemuan Peer Otomatis**: Plug and play

### 💼 Mudah Digunakan
- **GUI Desktop**: Aplikasi native untuk Windows/Linux/macOS
- **Dashboard Web**: Monitor node via browser

---

## 📚 Dokumentasi Lengkap (Bahasa Indonesia)

Kami telah menerjemahkan panduan lengkap untuk Anda:

1. **[PANDUAN INSTALASI](PANDUAN_INSTALASI.md)**  
   Cara install di Windows, Linux, macOS, dan Android.

2. **[PANDUAN PENGGUNA](PANDUAN_PENGGUNA.md)**  
   Cara menggunakan Wallet, Mining, dan Transaksi.

3. **[PANDUAN GENESIS & WALLET](PANDUAN_GENESIS.md)**  
   Cara membuat Genesis Wallet dan setup Mainnet.

4. **[PANDUAN JARINGAN (GossipSub)](PANDUAN_GOSSIPSUB.md)**  
   Detail teknis tentang jaringan P2P.

---

## 🎯 Arsitektur

```
┌─────────────────────────────────────────┐
│         rnr-core Blockchain             │
├─────────────────────────────────────────┤
│  Konsensus PoSSR                        │
│  ├─ 10 Shard (masing-masing 100 MB)    │
│  ├─ Algoritma VRF (Lotere)             │
│  └─ Voting Mayoritas 7/10              │
├─────────────────────────────────────────┤
│  Jaringan LibP2P GossipSub              │
│  ├─ Penemuan Peer Otomatis             │
│  └─ Enkripsi TLS                       │
├─────────────────────────────────────────┤
│  Penyimpanan & State                    │
│  ├─ LevelDB (Database)                 │
│  └─ Pruning Otomatis (Hemat Storage)   │
└─────────────────────────────────────────┘
```

---

## 🛠️ Cara Build (Pengembang)

```bash
# Node Utama
go build -o rnr-node ./cmd/rnr-node

# GUI Desktop
go build -o rnr-gui ./cmd/rnr-gui

# Tool Generator Wallet
go build -o genesis-wallet ./cmd/genesis-wallet
```

---

## 🌍 Gabung Jaringan

**Mainnet (Segera Hadir)**
```bash
rnr-node --config config/mainnet.yaml
```

**Testnet (Aktif)**
```bash
rnr-node --testnet
```

---

## 💬 Komunitas

- **Discord**: https://discord.gg/rnr-core
- **Telegram**: https://t.me/rnr_network

---

**Dibuat dengan ❤️ oleh tim rnr-core**
