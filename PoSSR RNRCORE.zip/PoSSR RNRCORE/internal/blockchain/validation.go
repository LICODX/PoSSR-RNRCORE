package blockchain

import (
	"fmt"
	"time"

	"github.com/username/rnr-core/internal/params"
	"github.com/username/rnr-core/pkg/types"
	"github.com/username/rnr-core/pkg/utils"
)

// ValidateTransaction verifies transaction signature and basic validity
func ValidateTransaction(tx types.Transaction) error {
	// 1. Check signature
	message := types.SerializeTransaction(tx)
	if !utils.Verify(tx.Sender[:], message, tx.Signature[:]) {
		return fmt.Errorf("invalid signature for tx %x", tx.ID)
	}

	// 2. Basic sanity checks
	if tx.Amount == 0 {
		return fmt.Errorf("zero amount transaction")
	}

	if tx.Sender == tx.Receiver {
		return fmt.Errorf("sender and receiver are the same")
	}

	return nil
}

// ValidateBlock performs comprehensive block validation
func ValidateBlock(block types.Block, prevHeader types.BlockHeader) error {
	// 1. Validate timestamp (not too far in future)
	now := time.Now().Unix()
	if block.Header.Timestamp > now+600 {
		return fmt.Errorf("block timestamp too far in future")
	}

	// 2. Validate previous block hash
	if block.Header.Height > 0 {
		expectedPrevHash := types.HashBlockHeader(prevHeader)
		if block.Header.PrevBlockHash != expectedPrevHash {
			return fmt.Errorf("invalid previous block hash")
		}
	}

	// 3. Validate block size
	blockSize := calculateBlockSize(block)
	if blockSize > params.MaxBlockSize {
		return fmt.Errorf("block too large: %d bytes (max %d)", blockSize, params.MaxBlockSize)
	}

	// 4. Validate Merkle Root
	var allTxHashes [][32]byte
	for _, shard := range block.Shards {
		for _, tx := range shard.TxData {
			allTxHashes = append(allTxHashes, tx.ID)
		}
	}

	calculatedRoot := utils.CalculateMerkleRoot(allTxHashes)
	if block.Header.MerkleRoot != calculatedRoot {
		return fmt.Errorf("merkle root mismatch: expected %x, got %x",
			calculatedRoot, block.Header.MerkleRoot)
	}

	// 5. Validate all transactions
	for _, shard := range block.Shards {
		for _, tx := range shard.TxData {
			if err := ValidateTransaction(tx); err != nil {
				return fmt.Errorf("invalid transaction in block: %v", err)
			}
		}
	}

	return nil
}

// calculateBlockSize estimates block size in bytes
func calculateBlockSize(block types.Block) uint64 {
	// Rough estimate: header + shards
	size := uint64(1024) // Header overhead
	for _, shard := range block.Shards {
		size += uint64(len(shard.TxData)) * 500 // Avg tx size
	}
	return size
}
