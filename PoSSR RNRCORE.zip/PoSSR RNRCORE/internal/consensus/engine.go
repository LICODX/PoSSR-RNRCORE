package consensus

import (
	"crypto/sha256"

	"github.com/username/rnr-core/pkg/types"
	"github.com/username/rnr-core/pkg/utils"
)

// SelectAlgorithm menggunakan VRF Seed untuk menentukan algoritma sorting
// Input yang sama akan selalu menghasilkan algoritma yang sama (deterministic)
func SelectAlgorithm(seed [32]byte) string {
	// Ambil byte terakhir dari seed sebagai selector
	// Modulo 6 untuk 6 algoritma berbeda
	selector := seed[31] % 6

	switch selector {
	case 0:
		return "QUICK_SORT"
	case 1:
		return "MERGE_SORT"
	case 2:
		return "HEAP_SORT"
	case 3:
		return "RADIX_SORT"
	case 4:
		return "TIM_SORT"
	case 5:
		return "INTRO_SORT"
	default:
		return "QUICK_SORT" // Fallback (should never reach)
	}
}

// MixHash combines ID and seed to create a sorting key
func MixHash(id [32]byte, seed [32]byte) string {
	h := sha256.New()
	h.Write(id[:])
	h.Write(seed[:])
	return string(h.Sum(nil))
}

// GenerateMerkleRoot is a placeholder for actual Merkle Root generation
func GenerateMerkleRoot(txs []types.Transaction) [32]byte {
	if len(txs) == 0 {
		return [32]byte{}
	}
	// Simplistic placeholder: hash of first tx ID
	return txs[0].ID
}

// StartRace adalah fungsi utama mining - menjalankan sorting race
func StartRace(mempool []types.Transaction, seed [32]byte) ([]types.Transaction, [32]byte) {
	// 1. Tentukan Algoritma berdasarkan VRF Seed
	algo := SelectAlgorithm(seed)

	// 2. Prepare sortable data dengan sorting keys
	sortableData := make([]SortableTransaction, len(mempool))
	for i, tx := range mempool {
		sortableData[i] = SortableTransaction{
			Tx:  tx,
			Key: MixHash(tx.ID, seed),
		}
	}

	// 3. Eksekusi algoritma sorting yang dipilih
	var sorted []SortableTransaction

	switch algo {
	case "QUICK_SORT":
		sorted = QuickSort(sortableData)
	case "MERGE_SORT":
		sorted = MergeSort(sortableData)
	case "HEAP_SORT":
		sorted = HeapSort(sortableData)
	case "RADIX_SORT":
		sorted = RadixSort(sortableData)
	case "TIM_SORT":
		sorted = TimSort(sortableData)
	case "INTRO_SORT":
		sorted = IntroSort(sortableData)
	default:
		// Fallback ke QuickSort jika algoritma tidak dikenali
		sorted = QuickSort(sortableData)
	}

	// 4. Extract sorted transactions dari wrapper
	result := make([]types.Transaction, len(sorted))
	for i, st := range sorted {
		result[i] = st.Tx
	}

	// 5. Generate Merkle Root dari sorted transactions
	var txHashes [][32]byte
	for _, tx := range result {
		txHashes = append(txHashes, tx.ID)
	}
	root := utils.CalculateMerkleRoot(txHashes)

	return result, root
}
