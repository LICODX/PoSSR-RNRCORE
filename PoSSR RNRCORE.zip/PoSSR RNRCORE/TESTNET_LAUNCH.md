# rnr-core Testnet Launch Guide

## 🎯 Goal
Launch public testnet dengan 3+ nodes untuk testing sebelum mainnet.

---

## 📋 Pre-Launch Checklist

### Local Testing
- [ ] Build semua binaries
- [ ] Test 3-node local network
- [ ] Verify blocks sync
- [ ] Test transactions
- [ ] Verify dashboard works

### Infrastructure
- [ ] Rent 3 VPS (min 4GB RAM, 64GB storage)
- [ ] Setup firewall rules
- [ ] Install Go on all servers
- [ ] Clone repository on all servers

### Configuration
- [ ] Generate testnet genesis wallet
- [ ] Update testnet.yaml with genesis address
- [ ] Create seed nodes list
- [ ] Setup monitoring

---

## 🚀 Launch Steps

### Step 1: Setup VPS (x3)

**Requirements per VPS**:
- Ubuntu 22.04 LTS
- 4 GB RAM
- 64 GB SSD
- Public IP address

**Providers**:
- DigitalOcean: $24/month
- Vultr: $24/month
- Linode: $24/month

### Step 2: Install on Each VPS

```bash
# SSH to VPS
ssh root@your-vps-ip

# Update system
apt update && apt upgrade -y

# Install Go
wget https://go.dev/dl/go1.21.6.linux-amd64.tar.gz
tar -C /usr/local -xzf go1.21.6.linux-amd64.tar.gz
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
source ~/.bashrc

# Clone repository
git clone https://github.com/username/rnr-core.git
cd rnr-core

# Build
go mod tidy
go build -o rnr-node ./cmd/rnr-node

# Setup firewall
ufw allow 22/tcp   # SSH
ufw allow 3000/tcp # P2P
ufw allow 8080/tcp # Dashboard
ufw allow 9545/tcp # RPC
ufw enable
```

### Step 3: Generate Testnet Genesis

On your local machine:
```powershell
.\genesis-wallet.exe
```

Copy the address to `config/testnet.yaml`:
```yaml
genesis:
  allocation:
    genesis_wallet: "PASTE_ADDRESS_HERE"
```

### Step 4: Start Seed Node 1

```bash
# On VPS 1 (seed1.testnet.rnr:3000)
./rnr-node --config config/testnet.yaml --port 3000

# Check logs
tail -f logs/testnet.log
```

### Step 5: Start Seed Node 2

```bash
# On VPS 2 (seed2.testnet.rnr:3000)
./rnr-node --config config/testnet.yaml --port 3000 --peers seed1.testnet.rnr:3000
```

### Step 6: Start Seed Node 3

```bash
# On VPS 3 (seed3.testnet.rnr:3000)
./rnr-node --config config/testnet.yaml --port 3000 --peers seed1.testnet.rnr:3000,seed2.testnet.rnr:3000
```

---

## 🔍 Verify Testnet Working

### Check Dashboard
```
http://seed1.testnet.rnr:8080
http://seed2.testnet.rnr:8080
http://seed3.testnet.rnr:8080
```

Should show:
- Same block height on all nodes
- Peers: 2-3
- Blocks being mined every 60s

### Check RPC
```bash
curl -X POST http://seed1.testnet.rnr:9545 -H "Content-Type: application/json" -d '{
  "jsonrpc": "2.0",
  "method": "eth_blockNumber",
  "params": [],
  "id": 1
}'
```

### Monitor Logs
```bash
# On each VPS
tail -f logs/testnet.log

# Look for:
# ✅ "Block #X added to chain"
# ✅ "Connected to peer"
# ✅ "Won the race! Proof Root: ..."
```

---

## 📢 Public Announcement

### Update Documentation
Update `README.md`:
```markdown
## Join Testnet

**Seed Nodes**:
- seed1.testnet.rnr:3000
- seed2.testnet.rnr:3000
- seed3.testnet.rnr:3000

**Run Command**:
```bash
rnr-node --testnet --peers seed1.testnet.rnr:3000
```

**Explorer**: http://seed1.testnet.rnr:8080
**RPC**: http://seed1.testnet.rnr:9545
```

### Social Media
```
🚀 rnr-core Testnet is LIVE!

Join our public testnet and help test the PoSSR consensus:

Seed Nodes:
- seed1.testnet.rnr:3000
- seed2.testnet.rnr:3000

Dashboard: http://seed1.testnet.rnr:8080

#blockchain #PoSSR #testnet
```

---

## 🐛 Troubleshooting

### Nodes Not Syncing
```bash
# Check connectivity
ping seed1.testnet.rnr

# Check firewall
ufw status

# Check logs
tail -n 100 logs/testnet.log | grep -i error
```

### High CPU Usage
```bash
# Normal for mining nodes
# To disable mining on some nodes:
rnr-node --config config/testnet.yaml --no-mining
```

### Database Growing Too Fast
```bash
# Increase pruning frequency
# Edit config/testnet.yaml:
pruning_window: 50  # Prune more aggressively
```

---

## 📊 Monitoring

### Setup Monitoring Dashboard

On one VPS, install Grafana:
```bash
# Install Prometheus
wget https://github.com/prometheus/prometheus/releases/download/v2.40.0/prometheus-2.40.0.linux-amd64.tar.gz
tar xvfz prometheus-2.40.0.linux-amd64.tar.gz
cd prometheus-2.40.0.linux-amd64

# Configure prometheus.yml
cat > prometheus.yml <<EOF
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'rnr-nodes'
    static_configs:
      - targets:
        - 'seed1.testnet.rnr:9090'
        - 'seed2.testnet.rnr:9090'
        - 'seed3.testnet.rnr:9090'
EOF

# Start
./prometheus --config.file=prometheus.yml
```

Access: `http://your-server:9090`

---

## ⏱️ Timeline

| Day | Activity |
|-----|----------|
| Day 1 | Rent VPS, setup infrastructure |
| Day 2 | Build and deploy to all nodes |
| Day 3 | Generate genesis, configure |
| Day 4 | Launch seed nodes |
| Day 5 | Monitor, fix issues |
| Day 7 | Public announcement |

---

## 💰 Cost Estimate

**VPS x3**: $72/month  
**Domain**: $12/year  
**Monitoring**: Free (self-hosted)

**Total**: ~$80/month

---

## ✅ Success Criteria

Testnet is successful when:
- [ ] 3+ nodes running 24/7
- [ ] Blocks synced across all nodes
- [ ] No forks or chain splits
- [ ] 10+ external users connected
- [ ] 100+ blocks mined
- [ ] No critical bugs found

---

## 🎯 After Testnet

1. **Collect feedback** from testers
2. **Fix bugs** found during testing
3. **Optimize** performance
4. **Security audit** by external firm
5. **Prepare mainnet** with lessons learned

Expected testnet duration: **4-8 weeks** before mainnet launch.
