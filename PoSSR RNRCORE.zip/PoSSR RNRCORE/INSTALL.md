# rnr-core Installation Guide

Complete installation instructions for all supported operating systems.

---

## Table of Contents
- [Windows Installation](#windows)
- [Linux Installation](#linux)
- [macOS Installation](#macos)
- [Android (Termux)](#android-termux)
- [Building from Source](#building-from-source)

---

## Windows

### Prerequisites
- **OS**: Windows 10/11 (64-bit)
- **RAM**: 4 GB minimum, 8 GB recommended
- **Storage**: 64 GB free space
- **Internet**: Stable connection for blockchain sync

### Method 1: Pre-built Binaries (Recommended)

1. **Download Release**
   - Go to: https://github.com/username/rnr-core/releases
   - Download `rnr-core-windows-amd64.zip`

2. **Extract Files**
   ```powershell
   # Extract to C:\rnr-core\
   Expand-Archive -Path rnr-core-windows-amd64.zip -DestinationPath C:\rnr-core\
   ```

3. **Run CLI Node**
   ```powershell
   cd C:\rnr-core
   .\rnr-node.exe --port 3000 --datadir .\data
   ```

4. **Run GUI Application** (Optional)
   ```powershell
   # Install OpenGL drivers first (if needed)
   # Download: https://fdossena.com/?p=mesa/index.frag
   # Extract opengl32.dll to rnr-core folder
   
   .\rnr-gui.exe
   ```

### Method 2: Build from Source

1. **Install Go 1.21+**
   - Download: https://go.dev/dl/
   - Install and add to PATH

2. **Clone Repository**
   ```powershell
   git clone https://github.com/username/rnr-core.git
   cd rnr-core
   ```

3. **Build**
   ```powershell
   go mod tidy
   go build -o rnr-node.exe .\cmd\rnr-node
   go build -o rnr-gui.exe .\cmd\rnr-gui
   ```

4. **Run**
   ```powershell
   .\rnr-node.exe
   ```

### Port Configuration

Add firewall rules:
```powershell
# Allow P2P port
New-NetFirewallRule -DisplayName "RNR P2P" -Direction Inbound -LocalPort 3000 -Protocol TCP -Action Allow

# Allow RPC port
New-NetFirewallRule -DisplayName "RNR RPC" -Direction Inbound -LocalPort 9545 -Protocol TCP -Action Allow

# Allow Dashboard
New-NetFirewallRule -DisplayName "RNR Dashboard" -Direction Inbound -LocalPort 8080 -Protocol TCP -Action Allow
```

---

## Linux

### Prerequisites
- **OS**: Ubuntu 20.04+, Debian 11+, or equivalent
- **RAM**: 4 GB minimum, 8 GB recommended
- **Storage**: 64 GB free space

### Method 1: Pre-built Binaries

1. **Download Release**
   ```bash
   wget https://github.com/username/rnr-core/releases/download/v4.0/rnr-core-linux-amd64.tar.gz
   ```

2. **Extract**
   ```bash
   tar -xzf rnr-core-linux-amd64.tar.gz
   cd rnr-core
   ```

3. **Make Executable**
   ```bash
   chmod +x rnr-node
   chmod +x rnr-gui
   ```

4. **Run**
   ```bash
   ./rnr-node --port 3000 --datadir ./data
   ```

### Method 2: Build from Source

1. **Install Dependencies**
   ```bash
   # Ubuntu/Debian
   sudo apt update
   sudo apt install -y git golang-1.21 build-essential

   # Fedora/RHEL
   sudo dnf install -y git golang gcc
   ```

2. **Clone and Build**
   ```bash
   git clone https://github.com/username/rnr-core.git
   cd rnr-core
   go mod tidy
   go build -o rnr-node ./cmd/rnr-node
   go build -o rnr-gui ./cmd/rnr-gui
   ```

3. **Install Systemd Service** (Optional)
   ```bash
   sudo nano /etc/systemd/system/rnr-core.service
   ```

   Add:
   ```ini
   [Unit]
   Description=RNR Core Blockchain Node
   After=network.target

   [Service]
   Type=simple
   User=rnr
   WorkingDirectory=/home/rnr/rnr-core
   ExecStart=/home/rnr/rnr-core/rnr-node --port 3000 --datadir /var/lib/rnr
   Restart=on-failure

   [Install]
   WantedBy=multi-user.target
   ```

   Enable:
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable rnr-core
   sudo systemctl start rnr-core
   ```

4. **Check Status**
   ```bash
   sudo systemctl status rnr-core
   sudo journalctl -u rnr-core -f
   ```

### Firewall Configuration (UFW)

```bash
sudo ufw allow 3000/tcp    # P2P
sudo ufw allow 9545/tcp    # RPC
sudo ufw allow 8080/tcp    # Dashboard
sudo ufw enable
```

---

## macOS

### Prerequisites
- **OS**: macOS 12 Monterey or later
- **RAM**: 8 GB recommended
- **Storage**: 64 GB free space

### Method 1: Homebrew (Recommended)

1. **Install Homebrew**
   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```

2. **Install rnr-core**
   ```bash
   brew tap username/rnr-core
   brew install rnr-core
   ```

3. **Run**
   ```bash
   rnr-node --port 3000 --datadir ~/Library/Application\ Support/rnr-core
   ```

### Method 2: Pre-built .app Bundle

1. **Download**
   - Go to: https://github.com/username/rnr-core/releases
   - Download `rnr-core-macos.dmg`

2. **Install**
   - Open DMG file
   - Drag `rnr-core.app` to Applications folder

3. **Run**
   - Open from Applications
   - If "unidentified developer" warning appears:
     ```bash
     sudo xattr -r -d com.apple.quarantine /Applications/rnr-core.app
     ```

### Method 3: Build from Source

1. **Install Xcode Command Line Tools**
   ```bash
   xcode-select --install
   ```

2. **Install Go**
   ```bash
   brew install go
   ```

3. **Clone and Build**
   ```bash
   git clone https://github.com/username/rnr-core.git
   cd rnr-core
   go mod tidy
   go build -o rnr-node ./cmd/rnr-node
   ```

4. **Run**
   ```bash
   ./rnr-node
   ```

---

## Android (Termux)

Run a full node on Android devices!

### Prerequisites
- **Android**: 10+ (64-bit)
- **RAM**: 6 GB minimum
- **Storage**: 128 GB recommended
- **App**: Termux from F-Droid

### Installation Steps

1. **Install Termux**
   - Download from: https://f-droid.org/en/packages/com.termux/
   - **NOT** from Google Play (outdated)

2. **Setup Storage Permission**
   ```bash
   termux-setup-storage
   ```

3. **Install Dependencies**
   ```bash
   pkg update && pkg upgrade
   pkg install git golang
   ```

4. **Clone Repository**
   ```bash
   cd ~/storage/shared
   git clone https://github.com/username/rnr-core.git
   cd rnr-core
   ```

5. **Build for Android**
   ```bash
   go mod tidy
   GOOS=android GOARCH=arm64 go build -o rnr-node-android ./cmd/rnr-node
   ```

6. **Run in Light Mode**
   ```bash
   ./rnr-node-android --light-mode --datadir ~/storage/shared/rnr-data
   ```

7. **Keep Screen On** (Optional)
   ```bash
   termux-wake-lock
   ```

---

## Building from Source (All Platforms)

### Requirements
- Go 1.21+
- Git
- 8 GB RAM for compilation

### Steps

```bash
# Clone
git clone https://github.com/username/rnr-core.git
cd rnr-core

# Install dependencies
go mod tidy

# Build CLI node
go build -ldflags="-s -w" -o rnr-node ./cmd/rnr-node

# Build GUI (requires Fyne dependencies)
go build -ldflags="-s -w" -o rnr-gui ./cmd/rnr-gui

# Build tools
go build -o stress-test ./cmd/stress-test
go build -o exploit-test ./cmd/exploit-test
```

### Cross-Compile

```bash
# For Windows from Linux/macOS
GOOS=windows GOARCH=amd64 go build -o rnr-node.exe ./cmd/rnr-node

# For Linux from Windows/macOS
GOOS=linux GOARCH=amd64 go build -o rnr-node ./cmd/rnr-node

# For macOS from Linux/Windows
GOOS=darwin GOARCH=amd64 go build -o rnr-node ./cmd/rnr-node
```

---

## Post-Installation

### 1. Create Wallet

**CLI Method**:
```bash
# Coming soon: wallet CLI tool
go run ./cmd/wallet-cli create
```

**GUI Method**:
1. Open `rnr-gui`
2. Click "Wallet" tab
3. Click "Create New Wallet"
4. **SAVE YOUR PRIVATE KEY SECURELY!**

### 2. Connect to Network

**Mainnet**:
```bash
./rnr-node --port 3000 --peers mainnet-seed1.rnr.network:3000,mainnet-seed2.rnr.network:3000
```

**Testnet**:
```bash
./rnr-node --port 3000 --testnet --peers testnet-seed.rnr.network:3000
```

### 3. Check Status

**CLI**:
```bash
# RPC call
curl -X POST http://localhost:9545 -H "Content-Type: application/json" -d '{
  "jsonrpc": "2.0",
  "method": "eth_blockNumber",
  "params": [],
  "id": 1
}'
```

**Dashboard**:
- Open browser: http://localhost:8080

**GUI**:
- Dashboard tab shows real-time metrics

---

## Troubleshooting

### Windows

**Issue**: "opengl32.dll missing"
```powershell
# Download Mesa OpenGL: https://fdossena.com/?p=mesa/index.frag
# Extract opengl32.dll to rnr-core folder
```

**Issue**: "Port 3000 already in use"
```powershell
# Find process using port
netstat -ano | findstr :3000
# Kill process
taskkill /PID <PID> /F

# Or use different port
.\rnr-node.exe --port 3001
```

### Linux

**Issue**: "Permission denied"
```bash
chmod +x rnr-node
```

**Issue**: "Cannot bind to port 3000"
```bash
# Use port above 1024 or run as root
./rnr-node --port 30000

# Or allow low ports
sudo setcap 'cap_net_bind_service=+ep' ./rnr-node
```

### macOS

**Issue**: "Developer cannot be verified"
```bash
sudo xattr -r -d com.apple.quarantine ./rnr-node
```

**Issue**: "Firewall blocking connections"
- System Preferences → Security & Privacy → Firewall
- Add rnr-node to allowed list

### Android (Termux)

**Issue**: "Storage permission denied"
```bash
termux-setup-storage
# Grant permission when prompted
```

**Issue**: "Build fails with 'cannot find package'"
```bash
# Clean and rebuild
go clean -cache
go mod tidy
go build ./cmd/rnr-node
```

---

## System Requirements Summary

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| **CPU** | 2 cores | 4+ cores |
| **RAM** | 4 GB | 8 GB |
| **Storage** | 64 GB | 256 GB SSD |
| **Network** | 10 Mbps | 100 Mbps |
| **OS** | Win10/Ubuntu 20/macOS 12 | Win11/Ubuntu 22/macOS 13 |

---

## Next Steps

1. ✅ Install node
2. ✅ Create wallet
3. ✅ Connect to network
4. 📖 Read [User Guide](USER_GUIDE.md)
5. 🔧 Configure for mining (optional)

---

## Support

- **Documentation**: https://docs.rnr.network
- **Discord**: https://discord.gg/rnr-core
- **GitHub Issues**: https://github.com/username/rnr-core/issues
- **Telegram**: https://t.me/rnr_core
