# rnr-core User Guide

Complete guide for using rnr-core blockchain node.

---

## Quick Start

### Running Your First Node

**Windows**:
```powershell
.\rnr-node.exe
```

**Linux/macOS**:
```bash
./rnr-node
```

The node will:
1. Create database at `./data/chaindata`
2. Start P2P server on port `3000`
3. Start RPC server on port `9545`
4. Start dashboard on port `8080`

---

## Using the GUI Application

### 1. Dashboard Tab

**Metrics Displayed**:
- Current block height
- Transactions per second (TPS)
- Total transactions processed
- Connected peers

**Recent Blocks**:
- View last 10 blocks
- Click to see block details

### 2. Wallet Tab

**Create New Wallet**:
1. Click "Create New Wallet"
2. **IMPORTANT**: Save your private key immediately!
3. Store it in a secure password manager

**Import Existing Wallet**:
1. Click "Import Wallet"
2. Paste your private key
3. Click "Import"

**Export Private Key**:
1. Click "Export Private Key"
2. Copy and store securely
3. ⚠️ Never share with anyone!

### 3. Send Transaction

1. Enter recipient address
2. Enter amount in RNR
3. Click "Send Transaction"
4. Transaction will be signed with your wallet

### 4. Peers Tab

View all connected peers and their status.

### 5. Settings Tab

Configure:
- Data directory path
- P2P port (default: 3000)
- RPC port (default: 9545)

---

## Using RPC API

### Get Block Number

```bash
curl -X POST http://localhost:9545 -H "Content-Type: application/json" -d '{
  "jsonrpc": "2.0",
  "method": "eth_blockNumber",
  "params": [],
  "id": 1
}'
```

### Get Balance

```bash
curl -X POST http://localhost:9545 -H "Content-Type: application/json" -d '{
  "jsonrpc": "2.0",
  "method": "eth_getBalance",
  "params": ["0xYourAddress"],
  "id": 1
}'
```

### Send Raw Transaction

```bash
curl -X POST http://localhost:9545 -H "Content-Type: application/json" -d '{
  "jsonrpc": "2.0",
  "method": "eth_sendRawTransaction",
  "params": ["0xSignedTransactionHex"],
  "id": 1
}'
```

---

## Command Line Options

```
--port <number>      P2P listening port (default: 3000)
--datadir <path>     Data directory (default: ./data/chaindata)
--peers <list>       Comma-separated seed nodes
--testnet            Connect to testnet
--light-mode         Run as light client (mobile)
```

### Examples

**Custom Port**:
```bash
./rnr-node --port 3001
```

**Custom Data Directory**:
```bash
./rnr-node --datadir /mnt/ssd/rnr-data
```

**Connect to Specific Peers**:
```bash
./rnr-node --peers node1.example.com:3000,node2.example.com:3000
```

**Testnet**:
```bash
./rnr-node --testnet
```

---

## Advanced Usage

### Running Multiple Nodes

**Node 1**:
```bash
./rnr-node --port 3000 --datadir ./node1
```

**Node 2**:
```bash
./rnr-node --port 3001 --datadir ./node2 --peers localhost:3000
```

### Monitoring with Dashboard

Open browser:
```
http://localhost:8080
```

### Stress Testing

```bash
./stress-test.exe --target localhost:3000 --workers 100 --duration 60s
```

### Security Testing

```bash
./exploit-test.exe
```

---

## Wallet Management

### Creating a Wallet (Programmatically)

```go
import "github.com/username/rnr-core/pkg/wallet"

w, _ := wallet.CreateWallet()
fmt.Println("Address:", w.Address)
fmt.Println("Private Key:", w.ExportPrivateKey())
```

### Signing Transactions

```go
tx, _ := w.CreateTransaction(
    "0xRecipientAddress",
    100,  // amount
    1,    // nonce
)
```

---

## Backup and Recovery

### Backup Important Files

1. **Wallet Private Key**
   - Store in password manager
   - Print and keep in safe

2. **Blockchain Data** (Optional)
   - `./data/chaindata/` directory
   - Can re-sync from network

### Recovery

**Restore Wallet**:
1. Open GUI → Wallet tab
2. Click "Import Wallet"
3. Enter your private key

**Restore Blockchain Data**:
- Just run the node, it will sync automatically

---

## Performance Optimization

### For Mining Nodes

**Increase RAM**:
- Minimum: 8 GB
- Recommended: 16 GB+

**Use SSD Storage**:
- NVMe SSD preferred
- Minimum: 256 GB

**Network**:
- Upload speed: 100 Mbps+
- Low latency connection

### For Light Nodes

```bash
./rnr-node --light-mode --datadir ./light-data
```

This will:
- Use less disk space
- Faster sync
- Lower bandwidth

---

## Troubleshooting

### Node Won't Start

**Check ports**:
```bash
# Linux/macOS
lsof -i :3000

# Windows
netstat -ano | findstr :3000
```

**Check logs**:
```bash
# If using systemd
sudo journalctl -u rnr-core -f
```

### Sync is Slow

1. Check internet connection
2. Add more peers: `--peers node1:3000,node2:3000`
3. Use `--light-mode` for faster initial sync

### Transaction Not Confirming

1. Check transaction in mempool
2. Verify nonce is correct
3. Ensure sufficient balance
4. Check network connectivity

---

## Security Best Practices

1. ✅ **Never share private key**
2. ✅ **Backup wallet to multiple locations**
3. ✅ **Use firewall rules**
4. ✅ **Keep node software updated**
5. ✅ **Use strong passwords for keystore**
6. ⚠️ **Don't run as root** (Linux)
7. ⚠️ **Don't expose RPC to internet**

---

## FAQ

**Q: How much disk space do I need?**
A: 64 GB minimum, grows ~1 GB per day

**Q: Can I mine on laptop?**
A: Not recommended; use desktop with good cooling

**Q: What's the block time?**
A: 60 seconds

**Q: How many confirmations for finality?**
A: 7 blocks (~7 minutes)

**Q: Can I run on Raspberry Pi?**
A: Yes, but use light mode

---

## Next Steps

- Join community: https://discord.gg/rnr-core
- Read whitepaper: https://rnr.network/whitepaper
- Contribute: https://github.com/username/rnr-core
