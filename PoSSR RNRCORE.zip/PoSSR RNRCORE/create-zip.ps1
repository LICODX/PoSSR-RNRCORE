# Simple ZIP Creator for GitHub Upload
# Perfect for Mobile/RDP users!

Write-Host "Creating ZIP file for easy GitHub upload..." -ForegroundColor Green
Write-Host ""

$projectPath = "c:\Users\Administrator\Documents\PoSSR RNRCORE"
$zipPath = "c:\Users\Administrator\Documents\PoSSR-RNRCORE.zip"

# Remove old zip
if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

# Create temp clean folder
$tempPath = "$env:TEMP\PoSSR-Upload"
if (Test-Path $tempPath) {
    Remove-Item -Recurse -Force $tempPath
}
New-Item -ItemType Directory -Path $tempPath | Out-Null

Write-Host "Copying files (excluding binaries and temp files)..." -ForegroundColor Yellow

# Copy all files except excluded ones
$excludePatterns = @("*.exe", "*.log", "*\data\*", "*.db", "*\.gemini\*", "*.zip", "*\node_modules\*")

Get-ChildItem -Path $projectPath -Recurse | Where-Object {
    $item = $_
    $shouldInclude = $true
    
    foreach ($pattern in $excludePatterns) {
        if ($item.FullName -like $pattern) {
            $shouldInclude = $false
            break
        }
    }
    
    $shouldInclude
} | ForEach-Object {
    $dest = $_.FullName.Replace($projectPath, $tempPath)
    
    if ($_.PSIsContainer) {
        if (-not (Test-Path $dest)) {
            New-Item -ItemType Directory -Path $dest -Force | Out-Null
        }
    }
    else {
        $destDir = Split-Path -Parent $dest
        if (-not (Test-Path $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }
        Copy-Item -Path $_.FullName -Destination $dest -Force
    }
}

Write-Host "Compressing to ZIP..." -ForegroundColor Yellow
Compress-Archive -Path "$tempPath\*" -DestinationPath $zipPath -Force

# Cleanup
Remove-Item -Recurse -Force $tempPath

$zipSize = [math]::Round((Get-Item $zipPath).Length / 1MB, 2)

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "SUCCESS! ZIP file created!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "File location: $zipPath" -ForegroundColor Cyan
Write-Host "File size: $zipSize MB" -ForegroundColor White
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "HOW TO UPLOAD TO GITHUB (3 OPTIONS):" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "OPTION 1: Mobile Upload (EASIEST)" -ForegroundColor Yellow
Write-Host "--------------------------------------------" -ForegroundColor Gray
Write-Host "1. Transfer ZIP to your Android device" -ForegroundColor White
Write-Host "   (via RDP shared folder or cloud storage)" -ForegroundColor Gray
Write-Host ""
Write-Host "2. On Android browser, open:" -ForegroundColor White
Write-Host "   https://github.com/LICODX/PoSSR-RNRCORE" -ForegroundColor Cyan
Write-Host ""
Write-Host "3. Tap 'Add file' -> 'Upload files'" -ForegroundColor White
Write-Host ""
Write-Host "4. Select the ZIP file" -ForegroundColor White
Write-Host ""
Write-Host "5. GitHub will auto-extract it!" -ForegroundColor Green
Write-Host ""
Write-Host ""
Write-Host "OPTION 2: Web Upload from RDP" -ForegroundColor Yellow
Write-Host "--------------------------------------------" -ForegroundColor Gray
Write-Host "Opening GitHub upload page..." -ForegroundColor White

try {
    Start-Process "https://github.com/LICODX/PoSSR-RNRCORE/upload/main"
    Write-Host "Browser opened! Drag & drop files." -ForegroundColor Green
}
catch {
    Write-Host "Please open manually:" -ForegroundColor Yellow
    Write-Host "https://github.com/LICODX/PoSSR-RNRCORE/upload/main" -ForegroundColor Cyan
}

Write-Host ""
Write-Host ""
Write-Host "OPTION 3: Extract and Upload Files" -ForegroundColor Yellow
Write-Host "--------------------------------------------" -ForegroundColor Gray
Write-Host "1. Extract ZIP file" -ForegroundColor White
Write-Host "2. Go to GitHub upload page" -ForegroundColor White
Write-Host "3. Drag all folders/files" -ForegroundColor White
Write-Host ""
Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "RECOMMENDED: Use Option 1 for mobile!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""

Write-Host "Press Enter to exit..."
Read-Host
