# Panduan Pengguna rnr-core

Selamat datang di blockchain rnr-core!

---

## 🚀 Cara Menjalankan Node

### 1. Mode Standar (Mainnet/Default)
Cukup jalankan perintah ini. Node akan otomatis membuat wallet, database, dan mulai mencari peer.
```powershell
./rnr-node
```

### 2. Mode Testnet
Gunakan ini untuk mencoba-coba tanpa resiko.
```powershell
./rnr-node --testnet
```

### 3. Cek Status (Dashboard)
Setelah node berjalan, buka browser (Chrome/Edge/Firefox) dan ketik:
👉 **[http://localhost:8080](http://localhost:8080)**

Anda bisa melihat:
- Tinggi Blok (Block Height) pada saat ini
- Jumlah Peer yang terkoneksi
- Transaksi per detik (TPS)

---

## 💰 Dompet (Wallet)

### Membuat Wallet Baru
Untuk saat ini, gunakan tool `genesis-wallet` atau tunggu versi GUI.
```powershell
./genesis-wallet.exe
```
Simpan **Private Key** dan **Address** yang muncul dengan aman!

### Mengirim Koin (Transaksi)
(Fitur ini akan tersedia via GUI Wallet atau command line di update berikutnya).

---

## ⛏️ Mining (Penambangan)

Mining berjalan otomatis saat Anda menjalankan node!
- Algoritma: **PoSSR** (Proof of Sequential Sorting Race).
- Tidak butuh VGA mahal. Menggunakan CPU dan RAM (sorting memory-hard).
- Semakin cepat CPU dan RAM Anda menyortir data, semakin besar peluang dapat reward.

---

## 🛠️ Perintah Lanjutan

| Opsi | Fungsi | Contoh |
|------|--------|--------|
| `--port` | Mengatur port P2P | `./rnr-node --port 3001` |
| `--datadir` | Lokasi database | `./rnr-node --datadir ./data-saya` |
| `--peers` | Koneksi manual ke node lain | `./rnr-node --peers IP_NODE_LAIN:3000` |
| `--gossipsub`| Aktifkan jaringan mesh (Default: ON) | `./rnr-node --gossipsub` |

---

## 🔒 Tips Keamanan

1. **JANGAN PERNAH** membagikan Private Key Anda kepada siapapun.
2. **Backup** file wallet Anda (jika ada file keystore).
3. Pastikan komputer Anda bebas virus.
