# Panduan Jaringan (GossipSub P2P)

rnr-core menggunakan teknologi jaringan canggih bernama **LipP2P GossipSub**. Ini adalah teknologi yang sama yang digunakan oleh **Ethereum 2.0** dan **IPFS**.

---

## 📡 Apa itu GossipSub?

Bayangkan seperti "gosip" di dunia nyata:
- Anda memberi tahu kabar ke 3 teman.
- 3 teman itu masing-masing memberi tahu ke 3 teman lainnya.
- Dalam waktu singkat, ribuan orang tahu kabar tersebut.

**Dalam Blockchain:**
- **Mesh Network**: Semua komputer (node) saling terhubung membentuk jaring-jaring.
- **Efisien**: Pesan (transaksi/blok) menyebar sangat cepat ke seluruh dunia.
- **Hemat Bandwidth**: Tidak perlu kirim ke semua orang, cukup ke tetangga terdekat.

---

## 🛠️ Topik Komunikasi

Node rnr-core "berlangganan" (subscribe) ke 3 saluran utama:

1. **`rnr/blocks/1.0.0`** 📦  
   Untuk menyebarkan Blok baru yang berhasil ditambang.

2. **`rnr/transactions/1.0.0`** 💸  
   Untuk menyebarkan Transaksi baru (agar masuk ke mempool semua orang).

3. **`rnr/proofs/1.0.0`** ✅  
   Untuk menyebarkan bukti (proof) shard consensus.

---

## 🔒 Keamanan (TLS Encryption)

Kami tidak mengirim data mentah/polos! Semua komunikasi dienkripsi.

- **Protokol**: Noise + TLS 1.3
- **Manfaat**: 
  - Hacker tidak bisa mengintip isi paket data.
  - Mencegah manipulasi data di tengah jalan (Man-in-the-Middle).

---

## ⚙️ Cara Menggunakan (Config)

Secara default, GossipSub **SUDAH AKTIF**. Anda tidak perlu setting apa-apa.

Namun jika ingin mengatur manual:

### Lewat Command Line:
```powershell
# Aktifkan (Default)
./rnr-node --gossipsub

# Matikan (Gunakan TCP biasa - Tidak disarankan)
./rnr-node --gossipsub=false
```

### Lewat Config File (mainnet.yaml):
```yaml
network:
  use_gossipsub: true
  max_peers: 50
```

---

## 🌐 Seed Nodes (Node Induk)

Saat pertama kali online, node Anda butuh "teman" pertama untuk kenalan. Inilah fungsi Seed Nodes.

Daftar Seed Node Resmi (Contoh):
- `/ip4/seed1.rnr.network/tcp/3000/p2p/QmSeed1...` (USA)
- `/ip4/seed2.rnr.network/tcp/3000/p2p/QmSeed2...` (Eropa)
- `/ip4/seed3.rnr.network/tcp/3000/p2p/QmSeed3...` (Asia)

Node Anda akan otomatis menghubungi mereka untuk mendapatkan daftar peer lainnya.
