# 💼 Panduan Wallet RNR

## 📝 Tentang Wallet Baru

Wallet RNR menggunakan teknologi modern dengan fitur:
- **12 Kata Mnemonic** (BIP39) - mudah di-backup dan restore
- **HD Wallet** (BIP32) - dapat generate banyak address dari satu seed
- **Format Address `rnr1`** (Bech32) - lebih aman dengan error detection

---

## 🆕 Membuat Wallet Baru

### Untuk Genesis Wallet (Initial Supply)

```bash
# Build tool (jika belum)
go build -o genesis-wallet.exe ./cmd/genesis-wallet

# Generate wallet
.\genesis-wallet.exe
```

**Output yang akan muncul:**

```
═══════════════════════════════════════════════
🔑 RNR Genesis Wallet Generator
═══════════════════════════════════════════════

✅ Genesis Wallet Created Successfully!

🔐 MNEMONIC PHRASE (12 Words):
───────────────────────────────────────────────
   abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about
───────────────────────────────────────────────

📬 ADDRESS (Bech32 format):
   rnr1...

🛤️  DERIVATION PATH:
   m/44'/999'/0'/0/0
```

### ⚠️ **PENTING - BACKUP MNEMONIC!**

1. ✏️ **Tulis 12 kata di KERTAS** (JANGAN digital!)
2. 🔒 Simpan di tempat AMAN (brankas, safe deposit box)
3. ❌ **JANGAN FOTO** atau simpan di cloud
4. ❌ **JANGAN SHARE** ke siapa pun
5. 💰 12 kata ini = **5 MILIAR RNR**

### File yang Tersimpan

File `genesis_wallet.json` akan berisi:
```json
{
  "mnemonic": "12 kata anda...",
  "address": "rnr1...",
  "derivation_path": "m/44'/999'/0'/0/0",
  "public_key": "..."
}
```

> [!CAUTION]
> **JANGAN upload file ini ke GitHub!** File `.gitignore` sudah mengabaikannya.

---

## 🔄 Restore Wallet dari Mnemonic

Jika Anda kehilangan file wallet tapi masih punya 12 kata:

```bash
# Build import tool (jika belum)
go build -o import-wallet.exe ./cmd/import-wallet

# Jalankan tool
.\import-wallet.exe
```

**Langkah-langkah:**

1. Masukkan 12 kata (dipisah spasi)
2. Tool akan restore wallet
3. Address yang muncul akan **SAMA PERSIS** dengan address asli
4. Pilih apakah ingin save ke file atau tidak

### Contoh:

```
═══════════════════════════════════════════════
🔓 RNR Wallet Import Tool
═══════════════════════════════════════════════

📝 Enter your 12-word mnemonic phrase:
   (separate words with spaces)

> abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about

✅ Wallet Imported Successfully!

📬 ADDRESS:
   rnr1...

🛤️  DERIVATION PATH:
   m/44'/999'/0'/0/0
```

---

## 🔐 Format Address RNR

### Struktur

```
rnr1qpzry9x8gf2tvdw0s3jn54khce6mua7lmqqqqqqqqqqqqqqqmc3s...
└┬┘ └──────────────────── Bech32 Data ────────────────────┘
 │
 └─ Prefix (rnr + separator "1")
```

### Karakteristik

- ✅ Selalu diawali dengan `rnr1`
- ✅ Case-insensitive (bisa huruf besar/kecil)
- ✅ Ada checksum untuk deteksi typo
- ✅ Panjang sekitar 91 karakter

### Validasi Address

Dalam kode:
```go
import "github.com/username/rnr-core/pkg/wallet"

if wallet.ValidateAddress("rnr1...") {
    fmt.Println("✅ Address valid")
}
```

---

## 🛠️ Penggunaan di Kode

### Import Package

```go
import "github.com/username/rnr-core/pkg/wallet"
```

### 1. Buat Wallet Baru

```go
// Generate wallet dengan mnemonic
w, err := wallet.CreateWallet()
if err != nil {
    panic(err)
}

fmt.Println("Mnemonic:", w.Mnemonic)      // 12 kata
fmt.Println("Address:", w.Address)         // rnr1...
```

### 2. Restore dari Mnemonic

```go
mnemonic := "abandon abandon abandon ..." // 12 kata

w, err := wallet.CreateWalletFromMnemonic(mnemonic)
if err != nil {
    panic(err)
}

// Address yang sama akan muncul setiap kali
fmt.Println("Address:", w.Address)
```

### 3. Sign Transaction

```go
// Buat transaction
tx := &types.Transaction{
    Sender:   sender,
    Receiver: receiver,
    Amount:   1000,
    Nonce:    1,
}

// Sign dengan wallet
err := w.SignTransaction(tx)
```

---

## 📋 Checklist Keamanan

### ✅ DO (Lakukan)

- [x] Tulis 12 kata di kertas
- [x] Simpan di tempat aman (offline)
- [x] Buat backup di kertas kedua (lokasi berbeda)
- [x] Validasi mnemonic setelah ditulis (restore untuk test)
- [x] Gunakan `.gitignore` untuk protect wallet files

### ❌ DON'T (Jangan)

- [ ] Simpan mnemonic di file digital
- [ ] Screenshot atau foto mnemonic
- [ ] Upload wallet file ke GitHub/cloud
- [ ] Share mnemonic via email/chat
- [ ] Simpan di password manager online
- [ ] Ketik mnemonic di komputer yang tidak aman

---

## 🔄 Migration dari Wallet Lama

Jika Anda punya wallet format lama (hex address):

### Wallet Lama (DEPRECATED)

```json
{
  "address": "8150a6af22851558...",
  "private_key": "77960578a5ee23da..."
}
```

### Langkah Migrasi

1. **Backup private key lama** (copy ke tempat aman)
2. Generate genesis wallet baru:
   ```bash
   .\genesis-wallet.exe
   ```
3. **Tulis 12 kata** di kertas
4. Update `config/mainnet.yaml`:
   ```yaml
   genesis:
     allocation:
       genesis_wallet: "rnr1..." # Paste address baru
   ```
5. Delete file `genesis_wallet.json` lama (setelah yakin backup)

> [!WARNING]
> **Wallet lama tidak bisa dipakai lagi!** Pastikan sudah backup sebelum delete.

---

## 🔍 Troubleshooting

### Problem: "Invalid mnemonic phrase"

**Penyebab:**
- Salah tulis kata
- Urutan kata salah
- Kata bukan dari BIP39 wordlist

**Solusi:**
- Periksa kembali setiap kata
- Pastikan 12 kata, bukan lebih/kurang
- Gunakan lowercase
- Cek wordlist: https://github.com/bitcoin/bips/blob/master/bip-0039/english.txt

### Problem: "Address berbeda setelah restore"

**Penyebab:**
- Mnemonic salah
- Ada typo pada kata

**Solusi:**
- Mnemonic yang sama = address yang sama (100%)
- Jika berbeda, berarti ada kesalahan penulisan
- Coba lagi dengan mnemonic yang benar

### Problem: Build error - "undefined: bip39"

**Penyebab:**
- Dependencies belum terinstall

**Solusi:**
```bash
go mod download
go mod tidy
```

---

## 📚 Referensi

### Standards

- **BIP39**: Mnemonic code for generating deterministic keys
  - https://github.com/bitcoin/bips/blob/master/bip-0039.mediawiki

- **BIP32**: Hierarchical Deterministic Wallets
  - https://github.com/bitcoin/bips/blob/master/bip-0032.mediawiki

- **Bech32**: Base32 address format
  - https://github.com/bitcoin/bips/blob/master/bip-0173.mediawiki

### RNR Specifics

- **Coin Type**: 999 (custom untuk RNR)
- **Default Path**: `m/44'/999'/0'/0/0`
- **Address Prefix**: `rnr1`
- **Curve**: Ed25519 (untuk signing)

---

## ❓ FAQ

**Q: Berapa kata yang harus saya backup?**  
A: **12 kata**. Semua kata harus dalam urutan yang benar.

**Q: Apakah bisa pakai password untuk mnemonic?**  
A: Ya, tapi by default tidak ada password. Untuk advanced users bisa pakai `CreateWalletFromMnemonicWithPassword()`.

**Q: Apakah address case-sensitive?**  
A: Tidak. `rnr1abc...` sama dengan `RNR1ABC...`. Tapi convention-nya lowercase.

**Q: Bagaimana kalau lupa mnemonic?**  
A: **Tidak ada cara untuk recover!** Ini alasan kenapa harus backup dengan baik.

**Q: Apakah bisa generate address baru dari mnemonic yang sama?**  
A: Ya, dengan HD wallet bisa derive multiple address. Gunakan `deriveKey(path)` dengan path berbeda.

**Q: Apa bedanya dengan wallet Ethereum/Bitcoin?**  
A: Konsepnya sama (BIP39/BIP32), tapi:
- Ethereum: `0x...` (hex)
- Bitcoin: `bc1...` (Bech32)
- **RNR: `rnr1...` (Bech32)**

---

## 🚀 Next Steps

Setelah generate genesis wallet:

1. ✅ Backup 12 kata
2. ✅ Update `config/mainnet.yaml` dengan address baru
3. ✅ Test restore wallet untuk memastikan backup benar
4. ✅ Simpan file `genesis_wallet.json` di lokasi AMAN
5. ✅ **JANGAN upload** `genesis_wallet.json` ke GitHub

**Happy wallet management! 🎉**
