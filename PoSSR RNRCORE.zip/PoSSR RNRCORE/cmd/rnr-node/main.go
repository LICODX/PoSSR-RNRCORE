package main

import (
	"context"
	"flag"
	"fmt"
	"time"

	"github.com/username/rnr-core/internal/blockchain"
	"github.com/username/rnr-core/internal/consensus"
	"github.com/username/rnr-core/internal/dashboard"
	"github.com/username/rnr-core/internal/p2p"
	"github.com/username/rnr-core/internal/storage"
	"github.com/username/rnr-core/pkg/types"
)

func main() {
	port := flag.Int("port", 3000, "P2P listening port")
	datadir := flag.String("datadir", "./data/chaindata", "Data directory for LevelDB")
	peers := flag.String("peers", "", "Comma-separated peer addresses")
	useGossipSub := flag.Bool("gossipsub", true, "Use GossipSub (recommended)")
	flag.Parse()

	fmt.Println("🚀 Starting rnr-core Mainnet Node...")
	fmt.Printf("Config: Port=%d | DataDir=%s\n", *port, *datadir)
	fmt.Println("Consensus: PoSSR | Block Size: 1 GB | Pruning: ON")

	// 1. Initialize Database
	db, err := storage.NewLevelDB(*datadir)
	if err != nil {
		fmt.Printf("Failed to open database: %v\n", err)
		return
	}
	defer db.GetDB().Close()

	// 2. Initialize Blockchain State
	chain := blockchain.NewBlockchain(db)
	tip := chain.GetTip()
	fmt.Printf("⛓️  Current Tip: Block #%d\n", tip.Height)

	// 3. Setup context
	ctx := context.Background()

	// 4. Start P2P Network
	if *useGossipSub {
		// Use GossipSub (modern, mesh network)
		node, err := p2p.NewGossipSubNode(ctx, *port)
		if err != nil {
			fmt.Printf("Failed to start GossipSub: %v\n", err)
			return
		}
		defer node.Close()

		// Connect to seed peers
		if *peers != "" {
			// Parse and connect to peers
			// Format: /ip4/192.168.1.1/tcp/3000/p2p/QmPeerID
			fmt.Printf("Connecting to peers: %s\n", *peers)
			// TODO: Parse comma-separated list
		}

		// Start peer discovery
		node.DiscoverPeers()

		// Listen for network messages
		node.ListenForBlocks(func(data []byte) {
			fmt.Println("📦 Received block from network")
			// TODO: Deserialize and add to chain
		})

		node.ListenForTransactions(func(data []byte) {
			fmt.Println("💸 Received transaction from network")
			// TODO: Add to mempool
		})

		node.ListenForProofs(func(data []byte) {
			fmt.Println("✅ Received proof from network")
			// TODO: Validate proof
		})

	} else {
		// Use legacy TCP (for compatibility)
		network := p2p.NewServer(fmt.Sprintf("0.0.0.0:%d", *port))
		go network.Start()
	}

	// 5. Start GUI Dashboard
	dashboard.StartServer("8080", chain, nil)

	// 6. Mining Loop
	fmt.Println("🏁 Mining Loop Started. Waiting for transactions...")

	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			// Mock: Generate some transactions for testing
			var txs []types.Transaction
			// TODO: Get from actual mempool

			if len(txs) > 0 {
				fmt.Printf("Detected %d transactions. Starting Race...\n", len(txs))

				lastHeader := chain.GetTip()
				_, proof := consensus.StartRace(txs, lastHeader.VRFSeed)

				fmt.Printf("✅ Won the race! Proof Root: %x\n", proof)

				// TODO: Broadcast proof via GossipSub
			}
		}
	}
}
