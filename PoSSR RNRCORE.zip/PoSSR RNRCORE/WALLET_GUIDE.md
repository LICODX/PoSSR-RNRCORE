# 💼 RNR Wallet Guide

## 📝 About the New Wallet System

RNR wallets use modern cryptographic technology with features:
- **12-Word Mnemonic** (BIP39) - easy to backup and restore
- **HD Wallet** (BIP32) - generate multiple addresses from one seed
- **`rnr1` Address Format** (Bech32) - safer with built-in error detection

---

## 🆕 Creating a New Wallet

### For Genesis Wallet (Initial Supply)

```bash
# Build the tool (if not already built)
go build -o genesis-wallet.exe ./cmd/genesis-wallet

# Generate wallet
.\genesis-wallet.exe
```

**Expected Output:**

```
═══════════════════════════════════════════════
🔑 RNR Genesis Wallet Generator
═══════════════════════════════════════════════

✅ Genesis Wallet Created Successfully!

🔐 MNEMONIC PHRASE (12 Words):
───────────────────────────────────────────────
   abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about
───────────────────────────────────────────────

📬 ADDRESS (Bech32 format):
   rnr1...

🛤️  DERIVATION PATH:
   m/44'/999'/0'/0/0
```

### ⚠️ **CRITICAL - BACKUP YOUR MNEMONIC!**

1. ✏️ **Write the 12 words on PAPER** (NOT digital!)
2. 🔒 Store in a SAFE location (safe, safety deposit box)
3. ❌ **DO NOT take photos** or store in cloud
4. ❌ **NEVER SHARE** with anyone
5. 💰 These 12 words control **5 BILLION RNR**

### Saved File

The `genesis_wallet.json` file will contain:
```json
{
  "mnemonic": "your 12 words...",
  "address": "rnr1...",
  "derivation_path": "m/44'/999'/0'/0/0",
  "public_key": "..."
}
```

> [!CAUTION]
> **DO NOT upload this file to GitHub!** The `.gitignore` file already excludes it.

---

## 🔄 Restoring Wallet from Mnemonic

If you lose your wallet file but still have the 12 words:

```bash
# Build import tool (if not already built)
go build -o import-wallet.exe ./cmd/import-wallet

# Run the tool
.\import-wallet.exe
```

**Steps:**

1. Enter your 12 words (space-separated)
2. Tool will restore the wallet
3. The address will be **EXACTLY THE SAME** as the original
4. Choose whether to save to file or not

### Example:

```
═══════════════════════════════════════════════
🔓 RNR Wallet Import Tool
═══════════════════════════════════════════════

📝 Enter your 12-word mnemonic phrase:
   (separate words with spaces)

> abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about

✅ Wallet Imported Successfully!

📬 ADDRESS:
   rnr1...

🛤️  DERIVATION PATH:
   m/44'/999'/0'/0/0
```

---

## 🔐 RNR Address Format

### Structure

```
rnr1qpzry9x8gf2tvdw0s3jn54khce6mua7lmqqqqqqqqqqqqqqqmc3s...
└┬┘ └──────────────────── Bech32 Data ────────────────────┘
 │
 └─ Prefix (rnr + separator "1")
```

### Characteristics

- ✅ Always starts with `rnr1`
- ✅ Case-insensitive (can be upper/lowercase)
- ✅ Has checksum for typo detection
- ✅ Length approximately 91 characters

### Address Validation

In code:
```go
import "github.com/username/rnr-core/pkg/wallet"

if wallet.ValidateAddress("rnr1...") {
    fmt.Println("✅ Valid address")
}
```

---

## 🛠️ Usage in Code

### Import Package

```go
import "github.com/username/rnr-core/pkg/wallet"
```

### 1. Create New Wallet

```go
// Generate wallet with mnemonic
w, err := wallet.CreateWallet()
if err != nil {
    panic(err)
}

fmt.Println("Mnemonic:", w.Mnemonic)      // 12 words
fmt.Println("Address:", w.Address)         // rnr1...
```

### 2. Restore from Mnemonic

```go
mnemonic := "abandon abandon abandon ..." // 12 words

w, err := wallet.CreateWalletFromMnemonic(mnemonic)
if err != nil {
    panic(err)
}

// Same address will appear every time
fmt.Println("Address:", w.Address)
```

### 3. Sign Transaction

```go
// Create transaction
tx := &types.Transaction{
    Sender:   sender,
    Receiver: receiver,
    Amount:   1000,
    Nonce:    1,
}

// Sign with wallet
err := w.SignTransaction(tx)
```

---

## 📋 Security Checklist

### ✅ DO

- [x] Write 12 words on paper
- [x] Store in safe location (offline)
- [x] Make backup on second paper (different location)
- [x] Validate mnemonic after writing (test restore)
- [x] Use `.gitignore` to protect wallet files

### ❌ DON'T

- [ ] Store mnemonic in digital files
- [ ] Screenshot or photograph mnemonic
- [ ] Upload wallet file to GitHub/cloud
- [ ] Share mnemonic via email/chat
- [ ] Store in online password manager
- [ ] Type mnemonic on unsecured computer

---

## 🔄 Migration from Old Wallet

If you have an old format wallet (hex address):

### Old Wallet (DEPRECATED)

```json
{
  "address": "8150a6af22851558...",
  "private_key": "77960578a5ee23da..."
}
```

### Migration Steps

1. **Backup old private key** (copy to safe location)
2. Generate new genesis wallet:
   ```bash
   .\genesis-wallet.exe
   ```
3. **Write down 12 words** on paper
4. Update `config/mainnet.yaml`:
   ```yaml
   genesis:
     allocation:
       genesis_wallet: "rnr1..." # Paste new address
   ```
5. Delete old `genesis_wallet.json` file (after backup confirmation)

> [!WARNING]
> **Old wallet cannot be used anymore!** Ensure backup before deleting.

---

## 🔍 Troubleshooting

### Problem: "Invalid mnemonic phrase"

**Causes:**
- Misspelled word
- Wrong word order
- Word not from BIP39 wordlist

**Solutions:**
- Double-check each word
- Ensure exactly 12 words, not more/less
- Use lowercase
- Check wordlist: https://github.com/bitcoin/bips/blob/master/bip-0039/english.txt

### Problem: "Different address after restore"

**Causes:**
- Wrong mnemonic
- Typo in words

**Solutions:**
- Same mnemonic = same address (100%)
- If different, there's a writing error
- Try again with correct mnemonic

### Problem: Build error - "undefined: bip39"

**Causes:**
- Dependencies not installed

**Solutions:**
```bash
go mod download
go mod tidy
```

---

## 📚 References

### Standards

- **BIP39**: Mnemonic code for generating deterministic keys
  - https://github.com/bitcoin/bips/blob/master/bip-0039.mediawiki

- **BIP32**: Hierarchical Deterministic Wallets
  - https://github.com/bitcoin/bips/blob/master/bip-0032.mediawiki

- **Bech32**: Base32 address format
  - https://github.com/bitcoin/bips/blob/master/bip-0173.mediawiki

### RNR Specifics

- **Coin Type**: 999 (custom for RNR)
- **Default Path**: `m/44'/999'/0'/0/0`
- **Address Prefix**: `rnr1`
- **Curve**: Ed25519 (for signing)

---

## ❓ FAQ

**Q: How many words do I need to backup?**  
A: **12 words**. All words must be in the correct order.

**Q: Can I use a password with the mnemonic?**  
A: Yes, but by default there's no password. For advanced users, use `CreateWalletFromMnemonicWithPassword()`.

**Q: Is the address case-sensitive?**  
A: No. `rnr1abc...` is the same as `RNR1ABC...`. But convention is lowercase.

**Q: What if I forget my mnemonic?**  
A: **There is NO way to recover!** This is why proper backup is critical.

**Q: Can I generate new addresses from the same mnemonic?**  
A: Yes, with HD wallet you can derive multiple addresses. Use `deriveKey(path)` with different paths.

**Q: How is this different from Ethereum/Bitcoin wallets?**  
A: The concept is the same (BIP39/BIP32), but:
- Ethereum: `0x...` (hex)
- Bitcoin: `bc1...` (Bech32)
- **RNR: `rnr1...` (Bech32)**

---

## 🚀 Next Steps

After generating genesis wallet:

1. ✅ Backup 12 words
2. ✅ Update `config/mainnet.yaml` with new address
3. ✅ Test wallet restoration to ensure backup is correct
4. ✅ Store `genesis_wallet.json` file in SAFE location
5. ✅ **DO NOT upload** `genesis_wallet.json` to GitHub

**Happy wallet management! 🎉**
