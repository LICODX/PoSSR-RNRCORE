# Mainnet Seed Nodes Configuration

# Official rnr-core Mainnet Seed Nodes
# Last updated: 2024-01-01

## Seed Node List

### Seed 1 (US East)
- **Location**: New York, USA
- **Multiaddr**: `/ip4/seed1.rnr.network/tcp/3000/p2p/QmSeed1XXXXXXXXXXXXXXXXXXXX`
- **HTTP Dashboard**: `http://seed1.rnr.network:8080`
- **RPC**: `http://seed1.rnr.network:9545`
- **Prometheus**: `http://seed1.rnr.network:9090`

### Seed 2 (EU)
- **Location**: Frankfurt, Germany
- **Multiaddr**: `/ip4/seed2.rnr.network/tcp/3000/p2p/QmSeed2XXXXXXXXXXXXXXXXXXXX`
- **HTTP Dashboard**: `http://seed2.rnr.network:8080`
- **RPC**: `http://seed2.rnr.network:9545`
- **Prometheus**: `http://seed2.rnr.network:9090`

### Seed 3 (Asia)
- **Location**: Singapore
- **Multiaddr**: `/ip4/seed3.rnr.network/tcp/3000/p2p/QmSeed3XXXXXXXXXXXXXXXXXXXX`
- **HTTP Dashboard**: `http://seed3.rnr.network:8080`
- **RPC**: `http://seed3.rnr.network:9545`
- **Prometheus**: `http://seed3.rnr.network:9090`

---

## How to Connect

### Via Config File

`config/mainnet.yaml`:
```yaml
network:
  bootstrap_peers:
    - /ip4/seed1.rnr.network/tcp/3000/p2p/QmSeed1XXX
    - /ip4/seed2.rnr.network/tcp/3000/p2p/QmSeed2XXX
    - /ip4/seed3.rnr.network/tcp/3000/p2p/QmSeed3XXX
```

### Via Command Line

```bash
rnr-node --mainnet --peers /ip4/seed1.rnr.network/tcp/3000/p2p/QmSeed1XXX,/ip4/seed2.rnr.network/tcp/3000/p2p/QmSeed2XXX
```

---

## Seed Node Requirements

To run an official seed node:

- **Hardware**: 16 GB RAM, 500 GB NVMe SSD
- **Network**: 1 Gbps, low latency
- **Uptime**: 99.9%+ availability
- **Monitoring**: Prometheus + Grafana
- **Security**: Firewall configured, auto-updates
- **Backup**: Daily blockchain snapshots

---

## Community Seed Nodes

Community members can also run seed nodes:

```bash
# Start your seed node
rnr-node --mainnet --port 3000

# Get your multiaddr from logs
# Share with community on Discord/Telegram
```

---

## Health Check

Verify seed nodes are online:

```bash
# Check dashboard
curl http://seed1.rnr.network:8080

# Check RPC
curl -X POST http://seed1.rnr.network:9545 -H "Content-Type: application/json" -d '{
  "jsonrpc": "2.0",
  "method": "eth_blockNumber",
  "params": [],
  "id": 1
}'

# Check Prometheus metrics
curl http://seed1.rnr.network:9090/metrics
```

---

## Contact

Report seed node issues:
- **Discord**: https://discord.gg/rnr-core
- **Telegram**: https://t.me/rnr_network
- **Email**: seeds@rnr.network
