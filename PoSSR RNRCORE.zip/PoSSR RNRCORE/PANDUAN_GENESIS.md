# Panduan Genesis & Wallet

Panduan ini khusus untuk **Initial Setup** (Persiapan Awal) blockchain, terutama bagi Anda yang ingin meluncurkan network sendiri atau menjadi partisipan awal.

---

## 🔑 Apa itu Genesis Wallet?

Genesis Wallet adalah dompet pertama yang diciptakan. Dompet ini akan menerima **seluruh suplai koin awal** (5 Miliar RNR) saat blockchain pertama kali dijalankan (Blok #0).

### Langkah 1: Membuat Genesis Wallet

Kami menyediakan tool khusus agar Anda tidak perlu pusing dengan koding.

1. **Build Tool-nya**:
   ```powershell
   go build -o genesis-wallet.exe ./cmd/genesis-wallet
   ```

2. **Jalankan Tool**:
   ```powershell
   ./genesis-wallet.exe
   ```

3. **Hasil**:
   Akan muncul file `genesis_wallet.json` berisi:
   - **Address**: Alamat dompet Anda (Contoh: `8150a6af...`)
   - **Private Key**: Kunci rahasia Anda.

   ⚠️ **PENTING**: Simpan Private Key ini di tempat sangat aman! Siapapun yang punya key ini bisa mengontrol 5 Miliar koin.

---

## 🌐 Langkah 2: Setup Genesis di Code

Agar blockchain mengenali wallet Anda sebagai pemilik awal:

1. Buka file `internal/blockchain/genesis.go`.
2. Cari baris `MainnetGenesisWallet`.
3. Ganti nilainya dengan **Address** yang Anda dapatkan tadi.

Contoh yang benar:
```go
// Mainnet Genesis Wallet
MainnetGenesisWallet = "8150a6af22851558e96cb9faad6b7e9cd5961179deb84c784fdf5bbb5d57b263"
```

4. **Simpan file** dan **Build ulang** node Anda:
   ```powershell
   go build -o rnr-node.exe ./cmd/rnr-node
   ```

---

## 🚀 Langkah 3: Meluncurkan Mainnet

Sekarang node Anda siap menjadi **Node Pertama** di dunia (Seed Node).

Jalankan:
```powershell
./rnr-node.exe --config config/mainnet.yaml
```

Node akan mulai berjalan dari Blok 0, dan saldo 5.000.000.000 RNR akan otomatis masuk ke Genesis Wallet Anda.

---

## ❓ FAQ (Pertanyaan Umum)

**Q: Apakah saya bisa mengubah Genesis Wallet nanti?**  
A: **TIDAK BISA**. Sekali blockchain berjalan, genesis block terkunci selamanya. Jika salah, harus ulang dari nol (reset network).

**Q: Apa bedanya Mainnet dan Testnet?**  
A: 
- **Mainnet**: Uang asli, genesis block tetap/fixed.
- **Testnet**: Uang mainan, genesis block bisa random, untuk percobaan.

**Q: Bagaimana cara membagikan koin dari Genesis Wallet?**  
A: Gunakan fitur transaksi (via CLI atau GUI nanti) untuk mengirim koin dari Genesis Wallet ke wallet pengguna lain (airdrop, ICO, team allocation, dll).
