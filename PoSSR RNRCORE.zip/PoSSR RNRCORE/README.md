# PoSSR-RNRCORE

**Proof of Statistical Sorting Redundancy - RNR Core Implementation**

A next-generation blockchain with heterogeneous consensus using rotating sorting algorithms.

---

## 🎯 Overview

PoSSR-RNRCORE is a revolutionary blockchain implementation that uses **6 different sorting algorithms** that rotate based on VRF (Verifiable Random Function) seeds. This creates a truly heterogeneous mining environment that is resistant to optimization attacks.

### Key Features

- ✅ **6 Sorting Algorithms**: QuickSort, MergeSort, HeapSort, RadixSort, TimSort, IntroSort
- 🔐 **BIP39 Mnemonic Wallets**: 12-word recovery phrases for secure wallet generation
- 🌳 **HD Wallets (BIP32)**: Hierarchical deterministic wallets with custom derivation path `m/44'/999'/0'/0/0`
- 🔗 **Bech32 Addresses**: Modern address format with `rnr1` prefix
- 🛡️ **Attack-Resistant**: No single algorithm dominates; attackers must optimize for all 6
- ⚡ **High Performance**: All algorithms execute in <50μs for typical transaction loads
- 🎲 **Deterministic Algorithm Selection**: VRFSeed ensures all nodes use the same algorithm per block

---

## 🚀 Quick Start

### Prerequisites

- Go 1.21 or later
- 4GB RAM minimum
- Windows/Linux/macOS

### Installation

```bash
# Clone the repository
git clone https://github.com/LICODX/PoSSR-RNRCORE.git
cd PoSSR-RNRCORE

# Install dependencies
go mod download

# Build the node
go build -o rnr-node.exe ./cmd/rnr-node
```

### Generate Genesis Wallet

```bash
# Build genesis wallet generator
go build -o genesis-wallet.exe ./cmd/genesis-wallet

# Generate wallet with 12-word mnemonic
./genesis-wallet.exe
```

**CRITICAL: Write down your 12-word mnemonic phrase immediately!**

### Import Existing Wallet

```bash
# Build wallet import tool
go build -o import-wallet.exe ./cmd/import-wallet

# Import wallet from mnemonic
./import-wallet.exe
```

---

## 📊 Algorithm Rotation

PoSSR uses deterministic algorithm selection based on VRF Seed:

```
VRFSeed[31] % 6:
  0 → QUICK_SORT   (Fastest average case)
  1 → MERGE_SORT   (Stable, predictable)
  2 → HEAP_SORT    (Memory efficient)
  3 → RADIX_SORT   (Non-comparison)
  4 → TIM_SORT     (Production optimized)
  5 → INTRO_SORT   (Best worst-case)
```

### Example Block Sequence

```
Block #100: VRFSeed[31]=0x07 (7 % 6 = 1) → MERGE_SORT
Block #101: VRFSeed[31]=0x15 (21 % 6 = 3) → RADIX_SORT
Block #102: VRFSeed[31]=0x0A (10 % 6 = 4) → TIM_SORT
```

---

## 🧪 Testing

### Run All Tests

```bash
go test ./... -v
```

### Test Specific Packages

```bash
# Test consensus (sorting algorithms)
go test ./internal/consensus -v

# Test wallet functionality
go test ./pkg/wallet -v

# Test blockchain core
go test ./internal/blockchain -v
```

### Benchmarks

```bash
# Benchmark sorting algorithms
go test ./internal/consensus -bench=.

# Example output:
# BenchmarkQuickSort-8    50000    30000 ns/op
# BenchmarkMergeSort-8    40000    35000 ns/op
# BenchmarkRadixSort-8    60000    25000 ns/op
```

---

## 🎬 Demo: Mainnet Simulation

Run a simulated mainnet with 15 blocks:

```bash
# Build demo
go build -o mainnet-demo.exe ./cmd/mainnet-demo

# Run simulation
./mainnet-demo.exe
```

The demo shows:
- ✅ Real-time algorithm rotation
- ✅ Transaction sorting performance
- ✅ Merkle root generation
- ✅ Attack scenario (malicious node attempting to bypass consensus)

---

## 📁 Project Structure

```
PoSSR-RNRCORE/
├── cmd/
│   ├── genesis-wallet/     # Genesis wallet generator
│   ├── import-wallet/      # Wallet import tool
│   ├── mainnet-demo/       # Network simulation demo
│   └── rnr-node/           # Full node implementation
├── internal/
│   ├── blockchain/         # Blockchain core logic
│   │   ├── blockchain.go   # Chain management
│   │   ├── genesis.go      # Genesis block creation
│   │   ├── validation.go   # Block validation
│   │   └── fork.go         # Fork resolution
│   ├── consensus/          # PoSSR consensus engine
│   │   ├── engine.go       # Algorithm selection
│   │   ├── sorting.go      # 6 sorting implementations
│   │   ├── aggregator.go   # Consensus aggregation
│   │   └── voting.go       # Vote tracking
│   ├── storage/            # LevelDB storage layer
│   ├── state/              # State management
│   └── p2p/                # P2P networking (GossipSub)
├── pkg/
│   ├── types/              # Core data structures
│   │   ├── block.go        # Block definitions
│   │   ├── transaction.go  # Transaction types
│   │   └── serialization.go
│   ├── wallet/             # Wallet implementation
│   │   ├── wallet.go       # Main wallet logic
│   │   ├── mnemonic.go     # BIP39 implementation
│   │   ├── hdwallet.go     # BIP32 HD wallets
│   │   └── address.go      # Bech32 address encoding
│   └── utils/              # Utility functions
├── config/
│   └── mainnet.yaml        # Mainnet configuration
├── docs/
│   ├── SORTING_ALGORITHMS.md  # Algorithm documentation
│   ├── WALLET_GUIDE.md        # Wallet user guide
│   ├── PANDUAN_WALLET.md      # Indonesian wallet guide
│   └── GENESIS_SETUP.md       # Genesis setup guide
├── .gitignore
├── go.mod
├── go.sum
└── README.md
```

---

## 🔐 Security Features

### 1. Algorithm Diversity

Attackers cannot optimize for a single algorithm. To dominate mining, they must be faster than honest nodes across **all 6 algorithms**, which is significantly harder.

### 2. VRF-Based Selection

The next algorithm is unpredictable (determined by future VRFSeed), preventing attackers from pre-optimizing specific blocks.

### 3. Consensus Verification

Blocks are only accepted if:
1. Correct algorithm was used (determined by VRFSeed)
2. Merkle root matches expected sorting order
3. All transaction signatures are valid

### 4. Wallet Security

- HD wallets with BIP32 derivation
- 12-word BIP39 mnemonics (easy backup)
- Bech32 addresses with error detection
- Private keys never stored in files

---

## 📚 Documentation

- [Sorting Algorithms Guide](docs/SORTING_ALGORITHMS.md) - Detailed explanation of all 6 algorithms
- [Wallet Guide (English)](docs/WALLET_GUIDE.md) - Complete wallet management guide
- [Panduan Wallet (Indonesian)](docs/PANDUAN_WALLET.md) - Panduan lengkap manajemen wallet
- [Genesis Setup](docs/GENESIS_SETUP.md) - How to configure genesis block

---

## 🎯 Performance Metrics

### Sorting Performance (100 transactions)

| Algorithm   | Time (μs) | Memory | Stable |
|-------------|-----------|--------|--------|
| QuickSort   | ~30       | Low    | No     |
| MergeSort   | ~35       | High   | Yes    |
| HeapSort    | ~32       | Low    | No     |
| RadixSort   | ~25       | Med    | Yes    |
| TimSort     | ~28       | Med    | Yes    |
| IntroSort   | ~29       | Low    | No     |

### Block Generation

- **Transaction Capacity**: 1000+ tx/block
- **Block Time**: ~5 seconds (configurable)
- **Sorting Overhead**: <50μs (negligible)
- **Validation Time**: <100ms

---

## 🛠️ Development

### Run Tests

```bash
go test ./... -v
```

### Run Benchmarks

```bash
go test ./internal/consensus -bench=. -benchmem
```

### Build All Binaries

```bash
# Windows
go build -o genesis-wallet.exe ./cmd/genesis-wallet
go build -o import-wallet.exe ./cmd/import-wallet
go build -o mainnet-demo.exe ./cmd/mainnet-demo
go build -o rnr-node.exe ./cmd/rnr-node

# Linux/macOS
go build -o genesis-wallet ./cmd/genesis-wallet
go build -o import-wallet ./cmd/import-wallet
go build -o mainnet-demo ./cmd/mainnet-demo
go build -o rnr-node ./cmd/rnr-node
```

---

## 📜 License

MIT License - See LICENSE file for details

---

## 🤝 Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📞 Contact

- **Project**: PoSSR-RNRCORE
- **Repository**: https://github.com/LICODX/PoSSR-RNRCORE
- **Issues**: https://github.com/LICODX/PoSSR-RNRCORE/issues

---

## 🌟 Acknowledgments

- BIP39/BIP32 specifications
- Go community for excellent libraries
- Bitcoin and Ethereum for blockchain inspiration
- Academic research on consensus algorithms

---

**Built with ❤️ for decentralization and security**
