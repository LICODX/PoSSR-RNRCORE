# Simple GitHub Upload via API (No Git Required!)
# Perfect for RDP/Mobile usage

param(
    [string]$Username = "",
    [string]$Token = ""
)

Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "🚀 EASY GitHub Upload (NO Git Installation Needed!)" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Step 1: Create ZIP file of project
Write-Host "📦 Creating ZIP file..." -ForegroundColor Yellow
$projectPath = "c:\Users\Administrator\Documents\PoSSR RNRCORE"
$zipPath = "c:\Users\Administrator\Documents\PoSSR-RNRCORE.zip"

# Remove old zip if exists
if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

# Files/folders to exclude
$exclude = @("*.exe", "*.log", "data", "*.db", ".gemini", "node_modules", "*.zip")

# Create temp folder for clean files
$tempPath = "$env:TEMP\PoSSR-RNRCORE-upload"
if (Test-Path $tempPath) {
    Remove-Item -Recurse -Force $tempPath
}
New-Item -ItemType Directory -Path $tempPath | Out-Null

# Copy files (excluding unwanted ones)
Write-Host "   Copying files..." -ForegroundColor Gray
Get-ChildItem -Path $projectPath -Recurse | ForEach-Object {
    $shouldExclude = $false
    foreach ($pattern in $exclude) {
        if ($_.FullName -like "*$pattern*") {
            $shouldExclude = $true
            break
        }
    }
    
    if (-not $shouldExclude) {
        $dest = $_.FullName.Replace($projectPath, $tempPath)
        if ($_.PSIsContainer) {
            if (-not (Test-Path $dest)) {
                New-Item -ItemType Directory -Path $dest -Force | Out-Null
            }
        }
        else {
            Copy-Item -Path $_.FullName -Destination $dest -Force
        }
    }
}

# Create ZIP
Write-Host "   Compressing..." -ForegroundColor Gray
Compress-Archive -Path "$tempPath\*" -DestinationPath $zipPath -Force

# Cleanup temp
Remove-Item -Recurse -Force $tempPath

$zipSize = (Get-Item $zipPath).Length / 1MB
Write-Host "✅ ZIP created: $zipPath ($([math]::Round($zipSize, 2)) MB)" -ForegroundColor Green
Write-Host ""

# Step 2: Provide upload instructions
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "📱 UPLOAD INSTRUCTIONS (Mobile-Friendly!)" -ForegroundColor Cyan
Write- "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "Option 1: MANUAL UPLOAD (EASIEST FOR MOBILE)" -ForegroundColor Green
Write-Host "─────────────────────────────────────────────────" -ForegroundColor Gray
Write-Host "1. Download ZIP ke Android:" -ForegroundColor White
Write-Host "   File location: $zipPath" -ForegroundColor Cyan
Write-Host "   (Use RDP file transfer atau shared drive)" -ForegroundColor Gray
Write-Host ""
Write-Host "2. Di Android browser, buka:" -ForegroundColor White
Write-Host "   https://github.com/LICODX/PoSSR-RNRCORE" -ForegroundColor Cyan
Write-Host ""
Write-Host "3. Klik 'Add file' → 'Upload files'" -ForegroundColor White
Write-Host ""
Write-Host "4. Upload ZIP file" -ForegroundColor White
Write-Host ""
Write-Host "5. GitHub akan auto-extract! ✅" -ForegroundColor Green
Write-Host ""
Write-Host ""
Write-Host "Option 2: DIRECT WEB UPLOAD (From RDP)" -ForegroundColor Yellow
Write-Host "─────────────────────────────────────────────────" -ForegroundColor Gray
Write-Host "Saya akan buka browser ke GitHub upload page:" -ForegroundColor White
Write-Host ""

try {
    Start-Process "https://github.com/LICODX/PoSSR-RNRCORE/upload/main"
    Write-Host "✅ Browser opened! Drag & drop files dari folder project." -ForegroundColor Green
}
catch {
    Write-Host "⚠️  Please manually open:" -ForegroundColor Yellow
    Write-Host "   https://github.com/LICODX/PoSSR-RNRCORE/upload/main" -ForegroundColor Cyan
}

Write-Host ""
Write-Host ""
Write-Host "Option 3: COMMAND-LINE UPLOAD (Advanced)" -ForegroundColor Yellow
Write-Host "─────────────────────────────────────────────────" -ForegroundColor Gray
Write-Host "If you have GitHub credentials:" -ForegroundColor White
Write-Host ""

if ($Username -eq "" -or $Token -eq "") {
    Write-Host "Run script dengan credentials:" -ForegroundColor Gray
    Write-Host '.\easy-upload.ps1 -Username "YourGitHubUser" -Token "ghp_YourToken"' -ForegroundColor Cyan
}
else {
    Write-Host "Uploading via GitHub API..." -ForegroundColor Yellow
    # This would use GitHub API to upload - complex for now
    Write-Host "⚠️  API upload belum diimplementasikan." -ForegroundColor Yellow
    Write-Host "   Gunakan Option 1 atau 2 di atas." -ForegroundColor White
}

Write-Host ""
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "✅ READY TO UPLOAD!" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "ZIP file location:" -ForegroundColor White
Write-Host "$zipPath" -ForegroundColor Cyan
Write-Host ""
Write-Host "File size: $([math]::Round($zipSize, 2)) MB" -ForegroundColor White
Write-Host ""
Write-Host "🎯 Recommended: Use Option 1 (Mobile Upload)" -ForegroundColor Yellow
Write-Host ""
