# GitHub Auto Upload Script for PoSSR-RNRCORE
# This script will guide you through uploading to GitHub

Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "🚀 PoSSR-RNRCORE GitHub Upload Assistant" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Check if Git is installed
$gitInstalled = $false
try {
    $null = git --version 2>$null
    $gitInstalled = $true
    Write-Host "✅ Git is already installed!" -ForegroundColor Green
} catch {
    Write-Host "❌ Git is not installed" -ForegroundColor Red
}

if (-not $gitInstalled) {
    Write-Host ""
    Write-Host "Attempting to download and install Git..." -ForegroundColor Yellow
    Write-Host ""
    
    # Download Git installer
    $gitInstallerUrl = "https://github.com/git-for-windows/git/releases/download/v2.43.0.windows.1/Git-2.43.0-64-bit.exe"
    $gitInstallerPath = "$env:TEMP\GitInstaller.exe"
    
    try {
        Write-Host "Downloading Git installer..." -ForegroundColor Yellow
        Invoke-WebRequest -Uri $gitInstallerUrl -OutFile $gitInstallerPath -UseBasicParsing
        
        Write-Host "✅ Git installer downloaded!" -ForegroundColor Green
        Write-Host ""
        Write-Host "Please install Git manually:" -ForegroundColor Yellow
        Write-Host "1. The installer is located at: $gitInstallerPath" -ForegroundColor White
        Write-Host "2. Run the installer and follow the prompts" -ForegroundColor White
        Write-Host "3. After installation, restart PowerShell" -ForegroundColor White
        Write-Host "4. Run this script again" -ForegroundColor White
        Write-Host ""
        
        # Open installer
        Start-Process $gitInstallerPath
        
        Write-Host "Press any key to exit after installing Git..."
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        exit
    } catch {
        Write-Host "❌ Failed to download Git installer: $_" -ForegroundColor Red
        Write-Host ""
        Write-Host "ALTERNATIVE: Manual Upload via GitHub Web" -ForegroundColor Yellow
        Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
        Write-Host "1. Go to: https://github.com/LICODX/PoSSR-RNRCORE" -ForegroundColor White
        Write-Host "2. Click 'Add file' → 'Upload files'" -ForegroundColor White
        Write-Host "3. Drag and drop this entire folder:" -ForegroundColor White
        Write-Host "   c:\Users\Administrator\Documents\PoSSR RNRCORE\" -ForegroundColor Cyan
        Write-Host "4. Commit changes" -ForegroundColor White
        Write-Host ""
        Write-Host "Press any key to exit..."
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        exit
    }
}

# Git is installed, proceed with setup
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "GitHub Configuration" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Get GitHub credentials
Write-Host "Enter your GitHub username:" -ForegroundColor Yellow
$username = Read-Host

Write-Host "Enter your GitHub email:" -ForegroundColor Yellow
$email = Read-Host

Write-Host "Enter your GitHub Personal Access Token (PAT):" -ForegroundColor Yellow
Write-Host "(Create one at: https://github.com/settings/tokens)" -ForegroundColor Gray
$token = Read-Host -AsSecureString
$tokenPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($token))

# Configure Git
Write-Host ""
Write-Host "Configuring Git..." -ForegroundColor Yellow
git config --global user.name "$username"
git config --global user.email "$email"

# Navigate to project directory
$projectPath = "c:\Users\Administrator\Documents\PoSSR RNRCORE"
Set-Location $projectPath

Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "Initializing Git Repository" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan

# Initialize repository
git init
Write-Host "✅ Repository initialized" -ForegroundColor Green

# Add remote
$repoUrl = "https://${username}:${tokenPlain}@github.com/LICODX/PoSSR-RNRCORE.git"
git remote add origin $repoUrl
Write-Host "✅ Remote added" -ForegroundColor Green

# Add all files (respecting .gitignore)
Write-Host ""
Write-Host "Adding files..." -ForegroundColor Yellow
git add .
Write-Host "✅ Files staged for commit" -ForegroundColor Green

# Commit
Write-Host ""
Write-Host "Creating commit..." -ForegroundColor Yellow
git commit -m "Initial commit: PoSSR-RNRCORE blockchain with 6 sorting algorithms

- Implemented heterogeneous consensus (PoSSR)
- 6 sorting algorithms: QuickSort, MergeSort, HeapSort, RadixSort, TimSort, IntroSort
- BIP39/BIP32 HD wallet system with Bech32 addresses
- VRF-based deterministic algorithm selection
- Complete mainnet simulation and attack demo
- Comprehensive documentation and testing"

Write-Host "✅ Commit created" -ForegroundColor Green

# Set main branch
git branch -M main

# Push to GitHub
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "Uploading to GitHub..." -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

try {
    git push -u origin main --force
    
    Write-Host ""
    Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host "✅ UPLOAD SUCCESSFUL!" -ForegroundColor Green
    Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host ""
    Write-Host "Your repository is now live at:" -ForegroundColor White
    Write-Host "https://github.com/LICODX/PoSSR-RNRCORE" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Yellow
    Write-Host "1. Visit the repository URL above" -ForegroundColor White
    Write-Host "2. Verify all files uploaded correctly" -ForegroundColor White
    Write-Host "3. Add repository description and topics" -ForegroundColor White
    Write-Host "4. Share with the community!" -ForegroundColor White
    
} catch {
    Write-Host "❌ Upload failed: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "Possible issues:" -ForegroundColor Yellow
    Write-Host "- Invalid Personal Access Token" -ForegroundColor White
    Write-Host "- Repository doesn't exist (create it on GitHub first)" -ForegroundColor White
    Write-Host "- Network connection issues" -ForegroundColor White
    Write-Host ""
    Write-Host "Try manual upload:" -ForegroundColor Yellow
    Write-Host "1. Go to https://github.com/LICODX/PoSSR-RNRCORE" -ForegroundColor White
    Write-Host "2. Use 'Add file' → 'Upload files'" -ForegroundColor White
}

Write-Host ""
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
