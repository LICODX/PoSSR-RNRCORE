Berikut adalah Blueprint Implementasi Kode (Codebase Implementation Blueprint) yang sangat mendetail dan lengkap dalam format Markdown. Dokumen ini disusun mengikuti struktur proyek Go (Golang) standar industri, siap untuk di-deploy sebagai struktur awal repositori GitHub Anda.
Salin kode di bawah ini ke file bernama IMPLEMENTATION.md atau CODE_STRUCTURE.md di repositori Anda.
# rnr-core: Code Implementation Blueprint v1.0

> **Architecture:** Modular Monolith in Go
> **Consensus:** PoSSR (Proof of Sequential Sorting Race)
> **Target System:** Linux/Unix (VPS & Android Termux via Go Build)

Dokumen ini menjelaskan struktur direktori, definisi tipe data, dan logika inti yang harus diimplementasikan untuk membangun node **rnr-core**.

---

## 1. Directory Structure (Layout)

Mengikuti standar *golang-standards/project-layout*.

```text
rnr-core/
├── cmd/
│   └── rnr-node/           # Entry point aplikasi (Main function)
│       └── main.go
├── config/                 # Konfigurasi node (Port, Peer seeds, Wallet)
│   └── config.yaml
├── internal/
│   ├── blockchain/         # Logika Rantai, Blok, dan Validasi
│   ├── consensus/          # Engine PoSSR (Sorting, VRF, Merkle)
│   ├── economics/          # Kalkulasi Halving & Reward
│   ├── mempool/            # Manajemen memori transaksi (Sharding)
│   ├── p2p/                # Networking (GossipSub / LibP2P)
│   └── storage/            # LevelDB Wrapper & Pruning Logic
├── pkg/
│   ├── types/              # Struktur Data Global (Structs)
│   └── utils/              # Helper functions (Hashing, Encoding)
├── go.mod                  # Go Module definition
└── README.md

2. Core Constants & Configuration
Definisi parameter vital sistem sesuai spesifikasi Whitepaper.
File: internal/params/constants.go
package params

const (
    // Dimensi Blok & Shard
    BlockTime       = 60                  // 1 Menit (detik)
    MaxBlockSize    = 1024 * 1024 * 1024  // 1 GB
    ShardSize       = 100 * 1024 * 1024   // 100 MB per Node
    NumShards       = 10                  // 10 Pemenang per Blok

    // Tokenomics (5 Billion Supply, 7% Decay / 3.5M Blocks)
    TotalSupply     = 5000000000
    InitialReward   = 100.0               // 10 koin x 10 node
    HalvingInterval = 3500000             // Blok
    DecayRate       = 0.07                // 7%

    // Storage
    PruningWindow   = 25                  // Hapus raw data setelah 25 blok
)

3. Data Structures (pkg/types)
Struktur data ini dirancang untuk efisiensi memori (Memory Alignment).
File: pkg/types/block.go
package types

// Transaction (500 Bytes avg)
// Menggunakan array byte tetap untuk menghindari GC Overhead berlebih
type Transaction struct {
    ID        [32]byte // SHA-256 Hash
    Sender    [32]byte
    Receiver  [32]byte
    Amount    uint64
    Nonce     uint64
    Signature [64]byte
    Payload   []byte   // Data Smart Contract (Optional)
}

// Block Header (Ringan, disimpan selamanya)
type BlockHeader struct {
    Version       uint32
    PrevBlockHash [32]byte
    MerkleRoot    [32]byte // Root dari gabungan 10 Shard Roots
    Timestamp     int64
    Height        uint64
    WinningNodes  [10][32]byte // PubKey 10 Pemenang
    VRFSeed       [32]byte     // Seed untuk blok berikutnya
}

// Full Block (Berat 1 GB, akan di-prune)
type Block struct {
    Header BlockHeader
    Shards [10]ShardData // Data 10 x 100 MB
}

// ShardData mewakili kontribusi 1 node
type ShardData struct {
    NodeID    [32]byte
    AlgoUsed  string   // e.g., "QuickSort"
    TxData    []Transaction
    ShardRoot [32]byte
}

4. Consensus Module: PoSSR Engine
Jantung dari sistem ini. Mengimplementasikan "The Race".
File: internal/consensus/engine.go
package consensus

import (
    "sort"
    "[github.com/rnr-core/pkg/types](https://github.com/rnr-core/pkg/types)"
)

// SelectAlgorithm menggunakan VRF Seed untuk menentukan aturan main
func SelectAlgorithm(seed [32]byte) string {
    // Ambil byte terakhir dari seed sebagai selector
    selector := seed[31] % 3
    switch selector {
    case 0: return "QUICK_SORT"
    case 1: return "MERGE_SORT"
    case 2: return "RADIX_SORT"
    default: return "QUICK_SORT"
    }
}

// StartRace adalah fungsi utama mining
func StartRace(mempool []types.Transaction, seed [32]byte) ([]types.Transaction, [32]byte) {
    // 1. Tentukan Algoritma
    algo := SelectAlgorithm(seed)
    
    // 2. Clone data untuk sorting (Safety)
    // Note: Di production gunakan Zero-Copy pointer swap untuk performa
    data := make([]types.Transaction, len(mempool))
    copy(data, mempool)

    // 3. Eksekusi Sorting
    // Kunci Pengurutan: Hash(TxID + Seed)
    switch algo {
    case "QUICK_SORT":
        sort.Slice(data, func(i, j int) bool {
            keyI := MixHash(data[i].ID, seed)
            keyJ := MixHash(data[j].ID, seed)
            return keyI < keyJ
        })
    // Implementasi algoritma lain...
    }

    // 4. Generate Merkle Root
    root := GenerateMerkleRoot(data)
    
    return data, root
}

5. Storage Module: Pruning Logic
Implementasi database dengan mekanisme penghapusan otomatis.
File: internal/storage/manager.go
package storage

import (
    "[github.com/syndtr/goleveldb/leveldb](https://github.com/syndtr/goleveldb/leveldb)"
)

type Store struct {
    db *leveldb.DB
}

// PruneOldBlocks dipanggil setiap kali blok baru ditambahkan
func (s *Store) PruneOldBlocks(currentHeight uint64) error {
    if currentHeight <= params.PruningWindow {
        return nil
    }

    // Target blok yang harus dihapus (N - 25)
    targetHeight := currentHeight - params.PruningWindow
    
    // Hapus BODY blok (transaksi raw 1 GB), tapi simpan HEADER
    key := GenerateBlockBodyKey(targetHeight)
    
    // LevelDB Delete (Fast I/O)
    err := s.db.Delete(key, nil)
    if err != nil {
        return err
    }
    
    // Lakukan CompactRange secara berkala untuk membebaskan disk space fisik
    if targetHeight % 100 == 0 {
        s.db.CompactRange(util.Range{Start: nil, Limit: nil})
    }
    
    return nil
}

6. Economics Module: Tokenomics
Logika matematika untuk emisi koin.
File: internal/economics/supply.go
package economics

import (
    "math"
    "[github.com/rnr-core/internal/params](https://github.com/rnr-core/internal/params)"
)

// GetBlockReward menghitung reward total untuk 1 blok (untuk dibagi ke 10 node)
func GetBlockReward(height uint64) float64 {
    // Tentukan fase halving (integer division)
    phase := float64(height / params.HalvingInterval)
    
    // Rumus Decay: Initial * (0.93 ^ Phase)
    decayFactor := math.Pow(1.0 - params.DecayRate, phase)
    
    totalReward := params.InitialReward * decayFactor
    
    return totalReward
}

// CalculateNodeShare menghitung jatah per node
func CalculateNodeShare(totalReward float64) float64 {
    return totalReward / float64(params.NumShards)
}

7. Main Entry Point
Menyatukan semua modul.
File: cmd/rnr-node/main.go
package main

import (
    "fmt"
    "log"
    "[github.com/rnr-core/internal/blockchain](https://github.com/rnr-core/internal/blockchain)"
    "[github.com/rnr-core/internal/consensus](https://github.com/rnr-core/internal/consensus)"
    "[github.com/rnr-core/internal/p2p](https://github.com/rnr-core/internal/p2p)"
)

func main() {
    fmt.Println("🚀 Starting rnr-core Node...")
    fmt.Println("Consensus: PoSSR | Block Size: 1 GB | Pruning: ON")

    // 1. Inisialisasi Database
    db := storage.NewLevelDB("./data/chaindata")

    // 2. Inisialisasi Blockchain State
    chain := blockchain.NewBlockchain(db)

    // 3. Start P2P Listener (Gossip)
    network := p2p.NewServer("0.0.0.0:3000")
    go network.Start()

    // 4. Mining Loop (The Race)
    for {
        // Ambil Transaksi dari Mempool
        txs := network.GetMempoolShard()
        
        if len(txs) > 0 {
            // Dapatkan Seed terbaru
            lastHeader := chain.GetTip()
            
            // LAKUKAN BALAPAN (Blocking Operation)
            sortedTxs, proof := consensus.StartRace(txs, lastHeader.VRFSeed)
            
            // Broadcast Bukti
            network.BroadcastProof(proof)
        }
    }
}

8. Build & Deployment Instructions
Cara mengompilasi kode ini menjadi binary yang dapat dijalankan.
Prerequisites
 * Go: Versi 1.21+
 * OS: Linux (Ubuntu 22.04 Recommended) atau Android (via Termux).
Compilation
# 1. Initialize Module
go mod init [github.com/username/rnr-core](https://github.com/username/rnr-core)

# 2. Tidy Dependencies
go mod tidy

# 3. Build Binary
go build -o rnr-node ./cmd/rnr-node

# 4. Run Optimization (Hapus debug info untuk binary lebih kecil)
go build -ldflags="-s -w" -o rnr-node-light ./cmd/rnr-node

Running on Android (Termux)
# Pastikan storage permission aktif
termux-setup-storage

# Jalankan node
./rnr-node-light --datadir /sdcard/rnr-data --light-mode

Catatan Pengembang:
Blueprint ini adalah kerangka dasar. Implementasi tingkat produksi memerlukan penambahan:
 * Merkle Patricia Trie untuk state database.
 * ED25519 Signatures untuk validasi transaksi.
 * gRPC untuk komunikasi antar node yang lebih efisien.
<!-- end list -->

