# Panduan Instalasi rnr-core

Panduan lengkap instalasi untuk semua sistem operasi.

---

## 🖥️ Windows (Paling Umum)

### Cara 1: Menggunakan File EXE (Mudah)

1. **Download** file `rnr-node.exe` (atau build sendiri).
2. **Buat Folder** baru, misal `C:\rnr-core`.
3. Pindahkan `rnr-node.exe` ke folder tersebut.
4. **Jalankan**:
   - Klik Start, ketik `cmd`, tekan Enter.
   - Ketik perintah berikut:
     ```powershell
     cd C:\rnr-core
     .\rnr-node.exe
     ```

### Cara 2: Build dari Source Code

1. Install **Go Language** (versi 1.21 ke atas) dari [go.dev](https://go.dev/dl/).
2. Buka Terminal/CMD.
3. Jalankan perintah:
   ```powershell
   git clone https://github.com/username/rnr-core.git
   cd rnr-core
   go mod tidy
   go build -o rnr-node.exe ./cmd/rnr-node
   ```
4. File `rnr-node.exe` siap digunakan!

---

## 🐧 Linux (Ubuntu/Debian)

### Persiapan
```bash
sudo apt update
sudo apt install git golang -y
```

### Instalasi
```bash
git clone https://github.com/username/rnr-core.git
cd rnr-core
go mod tidy
go build -o rnr-node ./cmd/rnr-node
```

### Menjalankan
```bash
./rnr-node
```

---

## 🍎 macOS

### Instalasi
```bash
# Install Go jika belum ada
brew install go

# Clone dan Build
git clone https://github.com/username/rnr-core.git
cd rnr-core
go mod tidy
go build -o rnr-node ./cmd/rnr-node
```

### Menjalankan
```bash
./rnr-node
```

---

## 📱 Android (Via Termux)

Anda bisa menjalankan full node di HP Android!

1. Install aplikasi **Termux** (download dari F-Droid, jangan Play Store).
2. Buka Termux, jalankan:
   ```bash
   pkg update
   pkg install git golang
   ```
3. Download dan Build:
   ```bash
   git clone https://github.com/username/rnr-core.git
   cd rnr-core
   go mod tidy
   go build -o rnr-node ./cmd/rnr-node
   ```
4. Jalankan (Mode Ringan):
   ```bash
   ./rnr-node --light-mode
   ```

---

## ⚙️ Spesifikasi Sistem

| Komponen | Minimum | Rekomendasi |
|----------|---------|-------------|
| **CPU** | 2 Core | 4 Core |
| **RAM** | 4 GB | 8 GB |
| **Storage** | 64 GB | 256 GB SSD |
| **Internet**| 10 Mbps | 100 Mbps |

---

## ❓ Masalah Umum (Troubleshooting)

**Masalah**: "Command not found" saat mengetik `go`.  
**Solusi**: Pastikan Anda sudah install Go dan restart komputer.

**Masalah**: Firewall blocking.  
**Solusi**: Izinkan akses untuk port 3000 (P2P), 9545 (RPC), dan 8080 (Dashboard).
